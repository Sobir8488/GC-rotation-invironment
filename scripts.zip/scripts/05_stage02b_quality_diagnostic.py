from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"
catp=OUT/"stage02b_los_rotation_catalog.csv"
auditp=OUT/"stage02b_rv_parse_audit.csv"
masterp=OUT/"stage02b_master_catalogue.csv"
txtp=OUT/"stage02b_quality_diagnostic.txt"
csvp=OUT/"stage02b_quality_breakdown.csv"

df=pd.read_csv(catp)

def bcol(name):
    if name not in df: return pd.Series(False,index=df.index)
    s=df[name]
    if s.dtype==bool: return s.fillna(False)
    return s.astype(str).str.lower().isin(["true","1","yes"])

fitok=bcol("primary_fit_ok")
nfit=pd.to_numeric(df.get("primary_n_fit"),errors="coerce")
bins=pd.to_numeric(df.get("primary_angular_bins_occupied"),errors="coerce")
gap=pd.to_numeric(df.get("primary_max_angular_gap_deg"),errors="coerce")
amp=pd.to_numeric(df.get("primary_a_rot_los_kms"),errors="coerce")
sig=pd.to_numeric(df.get("primary_sigma_int_kms"),errors="coerce")
nsel=pd.to_numeric(df.get("n_primary_selected"),errors="coerce")
nrows=pd.to_numeric(df.get("n_rows_parsed"),errors="coerce")

c_n=nfit>=20
c_bins=bins>=6
c_gap=gap<=150
finite=np.isfinite(amp)&np.isfinite(sig)
quality=fitok&c_n&c_bins&c_gap&finite

breakdown=pd.DataFrame({
    "cluster":df.get("cluster"),
    "rv_file":df.get("rv_file"),
    "n_rows_parsed":nrows,
    "n_primary_selected":nsel,
    "fit_ok":fitok,
    "n_fit":nfit,
    "n_ge_20":c_n,
    "angular_bins_occupied":bins,
    "bins_ge_6":c_bins,
    "max_angular_gap_deg":gap,
    "gap_le_150":c_gap,
    "finite_amp_sigma":finite,
    "primary_quality_recomputed":quality,
    "fit_message":df.get("primary_fit_message"),
    "a_rot_los_kms":amp,
    "sigma_int_kms":sig,
})
breakdown.to_csv(csvp,index=False)

lines=[]
lines.append("JAA_REPRO_REBUILD STAGE 02B - QUALITY DIAGNOSTIC")
lines.append("Generated UTC: "+datetime.now(timezone.utc).isoformat())
lines.append("")
lines.append("COUNTS")
lines.append(f"Total RV cluster files                 : {len(df)}")
lines.append(f"N with >=20 fitted stars              : {int(c_n.sum())}")
lines.append(f"N with >=6 occupied angular bins      : {int(c_bins.sum())}")
lines.append(f"N with max angular gap <=150 deg      : {int(c_gap.sum())}")
lines.append(f"N optimizer fit_ok                    : {int(fitok.sum())}")
lines.append(f"N finite amplitude + sigma            : {int(finite.sum())}")
lines.append(f"N passing all primary criteria        : {int(quality.sum())}")
lines.append("")
lines.append("SEQUENTIAL ATTRITION")
seq=np.ones(len(df),dtype=bool)
for name,mask in [
    ("n_fit >= 20",c_n),
    ("angular bins >= 6",c_bins),
    ("gap <=150 deg",c_gap),
    ("optimizer fit_ok",fitok),
    ("finite amp/sigma",finite),
]:
    before=int(seq.sum())
    seq=seq & mask.to_numpy()
    after=int(seq.sum())
    lines.append(f"{name:30s}: {before:3d} -> {after:3d}  (lost {before-after})")
lines.append("")
lines.append("DISTRIBUTIONS")
for label,s in [
    ("n_rows_parsed",nrows),("n_primary_selected",nsel),("n_fit",nfit),
    ("angular_bins_occupied",bins),("max_angular_gap_deg",gap),
    ("a_rot_los_kms",amp),("sigma_int_kms",sig)
]:
    x=s[np.isfinite(s)]
    if len(x):
        q=np.nanpercentile(x,[0,10,25,50,75,90,100])
        lines.append(label+": "+", ".join(f"{p:g}%={v:.4g}" for p,v in zip([0,10,25,50,75,90,100],q)))
    else:
        lines.append(label+": no finite values")
lines.append("")
lines.append("FIT MESSAGE COUNTS")
if "primary_fit_message" in df:
    for k,v in df["primary_fit_message"].fillna("<NA>").astype(str).value_counts().head(20).items():
        lines.append(f"{v:4d}  {k}")
lines.append("")
lines.append("TOP 30 CLUSTERS BY PRIMARY SELECTED N")
cols=["cluster","rv_file","n_primary_selected","primary_n_fit","primary_fit_ok",
      "primary_angular_bins_occupied","primary_max_angular_gap_deg",
      "primary_a_rot_los_kms","primary_sigma_int_kms","primary_fit_message"]
existing=[c for c in cols if c in df]
top=df.sort_values("n_primary_selected",ascending=False).head(30)[existing]
lines.append(top.to_string(index=False))
lines.append("")
lines.append("CLUSTERS WITH N_FIT>=20 BUT FAILED QUALITY")
bad=df.loc[c_n & ~quality,existing]
lines.append(bad.head(80).to_string(index=False) if len(bad) else "<none>")
lines.append("")
lines.append("POSSIBLE DIAGNOSIS FLAGS")
if int(c_n.sum()) >= 50 and int(c_bins.sum()) < 10:
    lines.append("* Angular geometry is the dominant failure; centre/RA-Dec interpretation must be checked.")
if int(c_n.sum()) >= 50 and int(fitok.sum()) < 10:
    lines.append("* Optimizer convergence is the dominant failure; inspect likelihood initialization/bounds.")
if int(c_n.sum()) < 20:
    lines.append("* Star-level membership/quality selection is the dominant attrition; inspect PMEM column semantics before changing thresholds.")
if int(np.isfinite(nrows).sum()) and np.nanmedian(nrows) > 1.5*np.nanmedian(nsel):
    lines.append("* Selection removes a large fraction of parsed rows; this may be correct, but PMEM/P_Single semantics need audit.")
if int(quality.sum()) <= 5:
    lines.append("* STOP: do not proceed to FDR/potential stages. Primary sample is too small relative to the intended population analysis.")

# Parse-audit token distributions
if auditp.exists():
    a=pd.read_csv(auditp)
    lines.append("")
    lines.append("RV PARSE AUDIT")
    lines.append(f"Rows in parse audit: {len(a)}")
    if "n_rows_parsed" in a:
        lines.append(f"Total parsed rows (audit): {pd.to_numeric(a['n_rows_parsed'],errors='coerce').sum():.0f}")
    if "token_widths" in a:
        lines.append("Representative token-width strings:")
        for x in a["token_widths"].dropna().astype(str).value_counts().head(10).items():
            lines.append(f"  {x[1]:3d} files: {x[0][:180]}")

txtp.write_text("\n".join(lines)+"\n",encoding="utf-8")

print("STAGE 02B QUALITY DIAGNOSTIC SUMMARY")
for ln in lines[3:10]:
    print(ln)
print("")
print("REPORTS WRITTEN:")
print("  outputs\\stage02b_quality_diagnostic.txt")
print("  outputs\\stage02b_quality_breakdown.csv")
