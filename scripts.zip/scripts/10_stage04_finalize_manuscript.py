from __future__ import annotations
import math, json, os, shutil, subprocess, sys, zipfile, hashlib
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yaml
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"
FINAL=ROOT/"FINAL_STAGE04"
FIG=FINAL/"figures"
TAB=FINAL/"tables"
SRC=FINAL/"source"
REP=FINAL/"repository_package"
for p in [FINAL,FIG,TAB,SRC,REP]:
    p.mkdir(parents=True,exist_ok=True)

FREEZE=yaml.safe_load((ROOT/"config"/"stage04_result_freeze.yaml").read_text(encoding="utf-8"))

REQ={
    "master":OUT/"stage02c_master_with_los.csv",
    "fits":OUT/"stage02c_los_rotation_catalog.csv",
    "stat":OUT/"stage03a_statistical_ledger.csv",
    "ctl":OUT/"stage03a_controlled_ledger.csv",
    "boot":OUT/"stage03a_bootstrap_summary.csv",
    "ext":OUT/"stage03b_external_validation_ledger_v2.csv",
    "ov":OUT/"stage03b_external_validation_overlap_v2.csv",
    "potvals":OUT/"stage03b_potential_cluster_values.csv",
    "pot":OUT/"stage03b_potential_ledger.csv",
    "potctl":OUT/"stage03b_controlled_potential_ledger.csv",
    "diffcat":OUT/"stage03b_differential_rotation_catalog.csv",
    "diff":OUT/"stage03b_differential_ledger.csv",
}
missing=[str(p) for p in REQ.values() if not p.exists()]
if missing:
    raise SystemExit("Missing required Stage 02C/03 outputs:\n  "+"\n  ".join(missing))

D={k:pd.read_csv(v) for k,v in REQ.items()}

def close(a,b,atol=5e-6,rtol=5e-5):
    return np.isfinite(a) and np.isfinite(b) and abs(a-b)<=atol+rtol*abs(b)

def require(cond,msg):
    if not cond:
        raise RuntimeError("FREEZE VALIDATION FAILED: "+msg)

# --- validate key frozen science results ---
pm=D["ext"].loc[D["ext"].layer=="Gaia_EDR3_PM_profile_validation"].iloc[0]
f=FREEZE["external_pm"]
require(int(pm.N)==int(f["N"]),"Gaia PM N changed")
require(close(float(pm.rho_s),f["rho_s"]),"Gaia PM rho changed")
require(close(float(pm.p),f["p"],atol=1e-10,rtol=5e-4),"Gaia PM p changed")

pr=D["stat"].loc[(D["stat"].family=="direct_environment")&(D["stat"].descriptor=="r_peri_kpc")].iloc[0]
f=FREEZE["primary_pericentre"]
require(int(pr.N)==int(f["N"]),"primary pericentre N changed")
require(close(float(pr.rho_s),f["rho_s"]),"primary pericentre rho changed")
require(close(float(pr.q_FDR),f["q"],atol=1e-9,rtol=5e-4),"primary pericentre q changed")

for name in ["structural","selection","full"]:
    r=D["ctl"].loc[D["ctl"].control_set==name].iloc[0]
    f=FREEZE["controls"][name]
    require(int(r.N)==int(f["N"]),f"{name} control N changed")
    require(close(float(r.rho_partial_s),f["rho"]),f"{name} control rho changed")
    require(close(float(r.q_FDR),f["q"],atol=1e-8,rtol=5e-4),f"{name} control q changed")

# --- curated tables ---
sample=pd.DataFrame([
    ["Merged structural-orbit master",172,"clusters","parent cluster-level union"],
    ["Individual RV input",161,"files","public per-cluster RV files"],
    ["Parser-valid RV layer",160,"files","coordinate/DCEN-consistent files"],
    ["Parsed individual RV layer",281170,"rows","stellar measurements"],
    ["Primary selected RV layer",54181,"rows","stellar rows entering primary fit"],
    ["Primary-quality LOS rotation",115,"clusters","main direct-rotation sample"],
    ["Strict-sensitivity LOS rotation",103,"clusters","stricter membership sample"],
    ["Matched Gaia EDR3 PM profiles",113,"clusters","safe PM-profile matches"],
    ["Independent PM-LOS overlap",101,"clusters","cross-channel validation"],
    ["Differential-rotation layer",115,"clusters","secondary inner/outer diagnostic"],
],columns=["layer","count","unit","role"])
sample.to_csv(TAB/"table01_sample_counts.csv",index=False)

D["ext"].to_csv(TAB/"table02_validation.csv",index=False)
D["stat"].to_csv(TAB/"table03_direct_environment.csv",index=False)
D["ctl"].to_csv(TAB/"table04_controls.csv",index=False)
D["pot"].loc[D["pot"].variant=="fiducial"].to_csv(TAB/"table05_potential_raw_fiducial.csv",index=False)
D["potctl"].loc[D["potctl"].variant=="fiducial"].to_csv(TAB/"table05_potential_controlled_fiducial.csv",index=False)
D["diff"].to_csv(TAB/"table06_differential.csv",index=False)
D["boot"].to_csv(TAB/"table07_bootstrap.csv",index=False)

# --- plot helpers ---
def save(fig,name):
    fig.tight_layout()
    fig.savefig(FIG/(name+".pdf"),bbox_inches="tight")
    fig.savefig(FIG/(name+".png"),dpi=300,bbox_inches="tight")
    plt.close(fig)

# Figure 1: PM validation
ov=D["ov"].dropna(subset=["primary_a_rot_los_kms","Arot_PM_kms"]).copy()
fig,ax=plt.subplots(figsize=(5.4,4.4))
ax.scatter(ov["Arot_PM_kms"],ov["primary_a_rot_los_kms"],s=28,alpha=0.75)
ax.set_xscale("log"); ax.set_yscale("log")
lo=max(min(ov["Arot_PM_kms"].min(),ov["primary_a_rot_los_kms"].min()),1e-3)
hi=max(ov["Arot_PM_kms"].max(),ov["primary_a_rot_los_kms"].max())
ax.plot([lo,hi],[lo,hi],linestyle="--",linewidth=1)
ax.set_xlabel(r"$A_{\rm rot}^{\rm PM}$ [km s$^{-1}$]")
ax.set_ylabel(r"$A_{\rm rot}^{\rm LOS}$ [km s$^{-1}$]")
ax.text(0.04,0.96,r"$N=101,\ \rho_S=0.3725$"+"\n"+r"$p=1.25\times10^{-4}$",
        transform=ax.transAxes,va="top")
save(fig,"fig01_external_pm_validation")

# Figure 2: direct pericentre
m=D["master"].dropna(subset=["primary_a_rot_los_kms","r_peri_kpc"]).copy()
fig,ax=plt.subplots(figsize=(5.4,4.4))
ax.scatter(m["r_peri_kpc"],m["primary_a_rot_los_kms"],s=28,alpha=0.75)
ax.set_xscale("log")
# Equal-count bins for display only
try:
    m["bin"]=pd.qcut(m["r_peri_kpc"],5,duplicates="drop")
    grp=m.groupby("bin",observed=True)
    x=grp["r_peri_kpc"].median()
    y=grp["primary_a_rot_los_kms"].median()
    ylo=y-grp["primary_a_rot_los_kms"].quantile(0.25)
    yhi=grp["primary_a_rot_los_kms"].quantile(0.75)-y
    ax.errorbar(x,y,yerr=np.vstack([ylo,yhi]),fmt="o",capsize=3)
except Exception:
    pass
ax.set_xlabel(r"$r_{\rm peri}$ [kpc]")
ax.set_ylabel(r"$A_{\rm rot}^{\rm LOS}$ [km s$^{-1}$]")
ax.text(0.04,0.96,r"$N=115,\ \rho_S=-0.3391$"+"\n"+r"$q_{\rm FDR}=8.39\times10^{-4}$",
        transform=ax.transAxes,va="top")
save(fig,"fig02_direct_rotation_pericentre")

# Figure 3: control attenuation
rawrho=float(pr.rho_s)
order=["raw","selection","structural","full"]
vals=[rawrho]
qs=[float(pr.q_FDR)]
for name in ["selection","structural","full"]:
    r=D["ctl"].loc[D["ctl"].control_set==name].iloc[0]
    vals.append(float(r.rho_partial_s)); qs.append(float(r.q_FDR))
fig,ax=plt.subplots(figsize=(5.6,4.2))
x=np.arange(len(order))
ax.axhline(0,linewidth=1)
ax.plot(x,vals,marker="o")
ax.set_xticks(x,["Raw","Selection","Structural","Full"])
ax.set_ylabel(r"Spearman / partial-Spearman coefficient")
for i,(v,q) in enumerate(zip(vals,qs)):
    ax.annotate(f"q={q:.3g}",(i,v),xytext=(0,8),textcoords="offset points",ha="center",fontsize=8)
save(fig,"fig03_control_attenuation")

# Potential merge
pv=D["potvals"].loc[D["potvals"].variant=="fiducial"].copy()
z=m.merge(pv,on="cluster_key",how="inner",suffixes=("","_pot"))
z["log_lambda"]=np.log10(z["lambda_max_abs_kms2_kpc2"])
z["log_tphi"]=np.log10(z["Tphi_peri"])
z["log_fj"]=np.log10(z["fJ_peri"])
z["log1p_arot"]=np.log10(1+z["primary_a_rot_los_kms"])

praw=D["pot"].loc[D["pot"].variant=="fiducial"].set_index("x")
pctl=D["potctl"].loc[D["potctl"].variant=="fiducial"].set_index("x")

def potential_plot(xcol,ycol,xlabel,ylabel,name,key):
    fig,ax=plt.subplots(figsize=(5.4,4.4))
    d=z[[xcol,ycol]].replace([np.inf,-np.inf],np.nan).dropna()
    ax.scatter(d[xcol],d[ycol],s=28,alpha=0.75)
    rr=praw.loc[key]; cc=pctl.loc[key]
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    ax.text(0.04,0.96,
            rf"raw $\rho_S={float(rr.rho_s):.3f}$, $q={float(rr.q_FDR):.3g}$"+"\n"+
            rf"full $\rho_{{partial}}={float(cc.rho_partial_s):.3f}$, $q={float(cc.q_FDR):.3g}$",
            transform=ax.transAxes,va="top",fontsize=8.5)
    save(fig,name)

potential_plot("log_lambda","primary_a_rot_los_kms",
               r"$\log_{10}[\lambda_{\max}(R=r_{\rm peri},z=0)]$",
               r"$A_{\rm rot}^{\rm LOS}$ [km s$^{-1}$]",
               "fig04_potential_lambda","log_lambda_max_peri")
potential_plot("log_tphi","log1p_arot",
               r"$\log_{10}\mathcal{T}_{\Phi,\rm peri}$",
               r"$\log_{10}(1+A_{\rm rot}^{\rm LOS})$",
               "fig05_potential_tphi","log_Tphi_peri")
potential_plot("log_fj","log1p_arot",
               r"$\log_{10}f_{J,\rm peri}^{\Phi}$",
               r"$\log_{10}(1+A_{\rm rot}^{\rm LOS})$",
               "fig06_potential_fj","log_fJ_peri")

# Figure 7: Dvec vs pericentre
dc=D["diffcat"].dropna(subset=["Dvec_LOS"]).merge(
    D["master"][["cluster_key","r_peri_kpc"]],on="cluster_key",how="inner"
).dropna(subset=["r_peri_kpc"])
dr=D["diff"].loc[(D["diff"].family=="differential_environment")&(D["diff"].y=="r_peri_kpc")].iloc[0]
fig,ax=plt.subplots(figsize=(5.4,4.4))
ax.scatter(dc["r_peri_kpc"],dc["Dvec_LOS"],s=28,alpha=0.75)
ax.set_xscale("log")
ax.set_xlabel(r"$r_{\rm peri}$ [kpc]")
ax.set_ylabel(r"$\mathcal{D}_{\vec{R}}^{\rm LOS}$")
ax.text(0.04,0.96,rf"$N={int(dr.N)},\ \rho_S={float(dr.rho_s):.3f}$"+"\n"+rf"$q={float(dr.q_FDR):.3f}$",
        transform=ax.transAxes,va="top")
save(fig,"fig07_differential_pericentre")

# --- freeze ledger ---
freeze_rows=[]
for _,r in D["ext"].iterrows():
    freeze_rows.append(dict(block="external",relation=r["layer"],N=r["N"],rho=r["rho_s"],p=r["p"],q=r["q_FDR"]))
for _,r in D["stat"].iterrows():
    freeze_rows.append(dict(block=r["family"],relation=r["descriptor"],N=r["N"],rho=r["rho_s"],p=r["p"],q=r["q_FDR"]))
for _,r in D["ctl"].iterrows():
    freeze_rows.append(dict(block="controlled_pericentre",relation=r["control_set"],N=r["N"],rho=r["rho_partial_s"],p=r["p"],q=r["q_FDR"]))
for _,r in D["pot"].loc[D["pot"].variant=="fiducial"].iterrows():
    freeze_rows.append(dict(block="potential_raw_fiducial",relation=f"{r['x']} vs {r['y']}",N=r["N"],rho=r["rho_s"],p=r["p"],q=r["q_FDR"]))
for _,r in D["potctl"].loc[D["potctl"].variant=="fiducial"].iterrows():
    freeze_rows.append(dict(block="potential_controlled_fiducial",relation=f"{r['x']} vs {r['y']}",N=r["N"],rho=r["rho_partial_s"],p=r["p"],q=r["q_FDR"]))
for _,r in D["diff"].iterrows():
    freeze_rows.append(dict(block=r["family"],relation=f"{r['x']} vs {r['y']}",N=r["N"],rho=r["rho_s"],p=r["p"],q=r["q_FDR"]))
pd.DataFrame(freeze_rows).to_csv(FINAL/"FINAL_RESULTS_FREEZE.csv",index=False)

# Copy final LaTeX and class
shutil.copy2(ROOT/"source"/"FINAL_JAA_REBUILT.tex",SRC/"FINAL_JAA_REBUILT.tex")
shutil.copy2(ROOT/"assets"/"jaa.cls",SRC/"jaa.cls")
for f in FIG.glob("*.pdf"):
    shutil.copy2(f,SRC/f.name)

# Submission readiness
readiness=[
    "JAA FINALIZATION - SUBMISSION READINESS",
    "Generated UTC: "+datetime.now(timezone.utc).isoformat(),
    "",
    "SCIENCE FREEZE: PASS",
    "  Stage 02C / 03A / 03B key coefficients match the frozen manifest.",
    "  Independent Gaia PM validation: PASS (N=101).",
    "  Controlled pericentre rows: complete numeric N/rho/p/q.",
    "  Potential controlled rows: complete numeric N/rho/p/q.",
    "  Differential environment family: complete numeric N/rho/p/q.",
    "",
    "MANUSCRIPT POLICY APPLIED:",
    "  Historical coefficients removed.",
    "  Historical EKMI dilution claims removed because they were not independently rebuilt.",
    "  No causal tidal-law claim.",
    "  Homologous light/heavy potential scaling is not presented as rank robustness.",
    "  Differential-vs-global correlation is treated as algebraically coupled diagnostic only.",
    "  Corresponding email: sobr8488@mail.ru.",
    "  Placeholder received/accepted dates removed.",
    "",
    "REMAINING SUBMISSION BLOCKERS:",
    "  1. Deposit FINAL_REPRODUCIBILITY_PACKAGE.zip in Zenodo or another public repository.",
    "  2. Replace [FINAL REPOSITORY DOI] in FINAL_JAA_REBUILT.tex.",
    "  3. Confirm whether a funding statement is required and provide the correct project, if any.",
    "  4. Authors should verify the author-contribution and AI-assistance declarations before submission.",
]
(FINAL/"SUBMISSION_READINESS.txt").write_text("\n".join(readiness)+"\n",encoding="utf-8")

# Repository README/CITATION
repo_readme="""Channel-specific Environmental Rotation Signatures in Galactic Globular Clusters
Reproducibility package

This archive contains derived result ledgers, frozen analysis configuration,
figure-generation products, reconstruction scripts, and the final manuscript source.

Raw public data are intentionally not redistributed. The reconstruction begins
from:
1. Baumgardt Galactic globular-cluster structural/orbit/individual-RV public data.
2. Vasiliev & Baumgardt (2021) Gaia EDR3 cluster archive:
   DOI 10.5281/zenodo.4891252

The result freeze is FINAL_RESULTS_FREEZE.csv.
The final manuscript source is source/FINAL_JAA_REBUILT.tex.

Important interpretation policy:
- historical manuscript numbers were checkpoints, not fit targets;
- the primary orbital association is not interpreted as an independent causal law;
- the light/fiducial/heavy mass-normalization variants are homologous and are
  not used as a rank-robustness test.
"""
(REP/"README.md").write_text(repo_readme,encoding="utf-8")
cff="""cff-version: 1.2.0
message: "If you use this reproducibility package, please cite the associated article and repository DOI."
title: "Reproducibility package for Channel-specific Environmental Rotation Signatures in Galactic Globular Clusters"
type: dataset
authors:
  - family-names: Turaev
    given-names: S. J.
  - family-names: Nuritdinov
    given-names: S. N.
  - family-names: Yuldoshev
    given-names: Q. X.
version: "1.0"
date-released: "2026-09-07"
"""
(REP/"CITATION.cff").write_text(cff,encoding="utf-8")

# Copy selected configs/scripts/outputs
for srcdir_name in ["config","scripts"]:
    srcdir=ROOT/srcdir_name
    if srcdir.exists():
        dstdir=REP/srcdir_name
        dstdir.mkdir(exist_ok=True)
        for p in srcdir.glob("*"):
            if p.is_file():
                shutil.copy2(p,dstdir/p.name)
outdst=REP/"derived_outputs"; outdst.mkdir(exist_ok=True)
selected_patterns=[
    "stage02a_schema_report.txt","stage02b_quality_diagnostic.txt",
    "stage02c_summary.txt","stage02c_los_rotation_catalog.csv",
    "stage02c_master_with_los.csv","stage03a_*.csv","stage03a_*.txt",
    "stage03b_*ledger*.csv","stage03b_*summary*.txt",
    "stage03b_gaia_pm_amplitudes_v2.csv","stage03b_gaia_profile_column_map.txt",
    "stage03b_potential_cluster_values.csv","stage03b_differential_rotation_catalog.csv",
]
seen=set()
for pat in selected_patterns:
    for p in OUT.glob(pat):
        if p.is_file() and p.name not in seen:
            shutil.copy2(p,outdst/p.name); seen.add(p.name)
shutil.copy2(FINAL/"FINAL_RESULTS_FREEZE.csv",REP/"FINAL_RESULTS_FREEZE.csv")
figdst=REP/"figures"; figdst.mkdir(exist_ok=True)
for p in FIG.glob("*"):
    shutil.copy2(p,figdst/p.name)
srcdst=REP/"manuscript"; srcdst.mkdir(exist_ok=True)
shutil.copy2(SRC/"FINAL_JAA_REBUILT.tex",srcdst/"FINAL_JAA_REBUILT.tex")
shutil.copy2(SRC/"jaa.cls",srcdst/"jaa.cls")

# Hash manifest
hash_lines=[]
for p in sorted([p for p in REP.rglob("*") if p.is_file()]):
    hash_lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(REP).as_posix()}")
(REP/"SHA256SUMS.txt").write_text("\n".join(hash_lines)+"\n",encoding="utf-8")

# Zip repository package
repozip=FINAL/"FINAL_REPRODUCIBILITY_PACKAGE.zip"
with zipfile.ZipFile(repozip,"w",zipfile.ZIP_DEFLATED) as zf:
    for p in REP.rglob("*"):
        if p.is_file():
            zf.write(p,p.relative_to(REP))

# Zip submission source
subzip=FINAL/"FINAL_JAA_SOURCE_PACKAGE.zip"
with zipfile.ZipFile(subzip,"w",zipfile.ZIP_DEFLATED) as zf:
    for p in SRC.rglob("*"):
        if p.is_file():
            zf.write(p,p.relative_to(SRC))

# Compile if pdflatex exists
pdf_status="SKIPPED (pdflatex not found)"
if shutil.which("pdflatex"):
    for _ in range(2):
        r=subprocess.run(["pdflatex","-interaction=nonstopmode","FINAL_JAA_REBUILT.tex"],
                         cwd=SRC,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (FINAL/"pdflatex.log").write_text(r.stdout,encoding="utf-8",errors="replace")
        if r.returncode!=0:
            raise RuntimeError("pdflatex failed; inspect FINAL_STAGE04/pdflatex.log")
    pdf_status="COMPILED"
    shutil.copy2(SRC/"FINAL_JAA_REBUILT.pdf",FINAL/"FINAL_JAA_REBUILT.pdf")

print("JAA STAGE 04 FINALIZATION COMPLETE")
print(f"Science freeze: PASS")
print(f"Figures: {len(list(FIG.glob('*.pdf')))} PDF + PNG pairs")
print(f"PDF status: {pdf_status}")
print("")
print("FINAL PRODUCTS:")
print("  FINAL_STAGE04\\FINAL_JAA_SOURCE_PACKAGE.zip")
print("  FINAL_STAGE04\\FINAL_REPRODUCIBILITY_PACKAGE.zip")
print("  FINAL_STAGE04\\FINAL_RESULTS_FREEZE.csv")
print("  FINAL_STAGE04\\SUBMISSION_READINESS.txt")
if (FINAL/"FINAL_JAA_REBUILT.pdf").exists():
    print("  FINAL_STAGE04\\FINAL_JAA_REBUILT.pdf")
print("")
print("Do not submit until [FINAL REPOSITORY DOI] is replaced and author declarations are verified.")
