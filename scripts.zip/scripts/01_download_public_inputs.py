from __future__ import annotations
import argparse, csv, hashlib, json, logging, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "outputs"
LOGS = ROOT / "logs"
for p in (RAW, OUT, LOGS): p.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOGS / "stage01_download.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)

S = requests.Session()
S.headers.update({"User-Agent": "JAA-REPRO-REBUILD/1.0 (academic reproducibility audit)"})

SOURCES = {
    "structural_html": "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/newdata/parameter.html",
    "structural_ascii": "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/newdata/combined_table.txt",
    "orbits_html": "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/newdata/orbits.html",
    "orbits_ascii": "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/newdata/orbits_table.txt",
    "rv_index": "https://people.smp.uq.edu.au/HolgerBaumgardt/globular/newdata/indivdata/data.html",
    "gaia_zenodo": "https://zenodo.org/records/4891252/files/clusters.zip?download=1",
}

MANIFEST_FIELDS = ["name","url","local_path","status","http_status","bytes","sha256","retrieved_utc","note"]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def get(url: str, timeout=90, attempts=5, stream=False):
    last = None
    for k in range(1, attempts+1):
        try:
            r = S.get(url, timeout=timeout, stream=stream, allow_redirects=True)
            if r.status_code == 200:
                return r
            last = RuntimeError(f"HTTP {r.status_code} for {url}")
        except Exception as e:
            last = e
        logging.warning("Attempt %d/%d failed for %s: %s", k, attempts, url, last)
        time.sleep(min(2**k, 20))
    raise last


def save_response(name: str, url: str, dest: Path, note="") -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        return dict(name=name,url=url,local_path=str(dest.relative_to(ROOT)),status="cached",
                    http_status=200,bytes=dest.stat().st_size,sha256=sha256_file(dest),
                    retrieved_utc="cached",note=note)
    r = get(url, stream=True)
    with dest.open("wb") as f:
        for chunk in r.iter_content(chunk_size=1024*1024):
            if chunk: f.write(chunk)
    return dict(name=name,url=url,local_path=str(dest.relative_to(ROOT)),status="downloaded",
                http_status=r.status_code,bytes=dest.stat().st_size,sha256=sha256_file(dest),
                retrieved_utc=datetime.now(timezone.utc).isoformat(),note=note)


def discover_rv_links(index_html: str, base_url: str):
    soup = BeautifulSoup(index_html, "html.parser")
    combined = None
    cluster_links = []
    for a in soup.find_all("a", href=True):
        text = " ".join(a.stripped_strings)
        href = urljoin(base_url, a["href"])
        low = text.lower()
        if "combined radial velocity" in low or ("ascii" in low and "radial" in low):
            combined = href
        tr = a.find_parent("tr")
        if tr is not None:
            cells = [" ".join(td.stripped_strings) for td in tr.find_all(["td","th"])]
            if len(cells) >= 2 and ("rv data" in low or low == "data"):
                cluster = re.sub(r"\s+", " ", cells[0]).strip()
                cluster_links.append((cluster, href))
    # de-duplicate
    seen, out = set(), []
    for c,u in cluster_links:
        key=(c,u)
        if key not in seen:
            seen.add(key); out.append((c,u))
    return combined, out


def safe_name(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s.strip())
    return s.strip("_") or "cluster"


def download_core():
    rows=[]
    # Save source HTML snapshots first
    for key in ("structural_html","orbits_html","rv_index"):
        url=SOURCES[key]
        dest=RAW / f"{key}.html"
        try:
            rows.append(save_response(key,url,dest,"source-page snapshot"))
        except Exception as e:
            logging.error("Could not download %s: %s", key, e)
            rows.append(dict(name=key,url=url,local_path=str(dest.relative_to(ROOT)),status="failed",
                             http_status="",bytes=0,sha256="",retrieved_utc=datetime.now(timezone.utc).isoformat(),note=str(e)))

    # Preferred combined ASCII tables; HTML snapshots remain fallbacks for Stage 02
    for key, fname in (("structural_ascii","baumgardt_structural_combined.txt"),
                       ("orbits_ascii","baumgardt_orbits_combined.txt")):
        url=SOURCES[key]; dest=RAW/fname
        try:
            rows.append(save_response(key,url,dest,"preferred machine-readable source"))
        except Exception as e:
            logging.warning("ASCII download failed; HTML fallback retained: %s", e)
            rows.append(dict(name=key,url=url,local_path=str(dest.relative_to(ROOT)),status="failed_html_fallback_available",
                             http_status="",bytes=0,sha256="",retrieved_utc=datetime.now(timezone.utc).isoformat(),note=str(e)))

    # RV layer: prefer combined ASCII discovered from live index; otherwise per-cluster files
    rv_html_path=RAW/"rv_index.html"
    if rv_html_path.exists():
        html=rv_html_path.read_text(encoding="utf-8",errors="replace")
        combined, cluster_links=discover_rv_links(html,SOURCES["rv_index"])
        discovery={"combined_url":combined,"n_cluster_links":len(cluster_links),"cluster_links":cluster_links}
        (OUT/"rv_link_discovery.json").write_text(json.dumps(discovery,indent=2,ensure_ascii=False),encoding="utf-8")
        if combined:
            try:
                rows.append(save_response("rv_combined",combined,RAW/"baumgardt_rv_combined.txt","combined individual-star RV catalogue"))
                cluster_links=[]  # no need for per-cluster fallback
            except Exception as e:
                logging.warning("Combined RV download failed; using per-cluster fallback: %s", e)
        if cluster_links:
            rvdir=RAW/"rv_by_cluster"; rvdir.mkdir(exist_ok=True)
            for i,(cluster,url) in enumerate(cluster_links,1):
                try:
                    rows.append(save_response(f"rv_{cluster}",url,rvdir/f"{safe_name(cluster)}.txt","per-cluster RV fallback"))
                except Exception as e:
                    rows.append(dict(name=f"rv_{cluster}",url=url,local_path=str((rvdir/f"{safe_name(cluster)}.txt").relative_to(ROOT)),status="failed",
                                     http_status="",bytes=0,sha256="",retrieved_utc=datetime.now(timezone.utc).isoformat(),note=str(e)))
                if i % 20 == 0: logging.info("RV files processed: %d/%d",i,len(cluster_links))
                time.sleep(0.15)
    return rows


def download_gaia():
    try:
        return [save_response("gaia_edr3_clusters_zip",SOURCES["gaia_zenodo"],RAW/"vasiliev_baumgardt_2021_clusters.zip","DOI 10.5281/zenodo.4891252")]
    except Exception as e:
        return [dict(name="gaia_edr3_clusters_zip",url=SOURCES["gaia_zenodo"],local_path="data/raw/vasiliev_baumgardt_2021_clusters.zip",status="failed",
                     http_status="",bytes=0,sha256="",retrieved_utc=datetime.now(timezone.utc).isoformat(),note=str(e))]


def merge_manifest(new_rows):
    path=OUT/"provenance_manifest.csv"
    old=[]
    if path.exists():
        with path.open(encoding="utf-8",newline="") as f: old=list(csv.DictReader(f))
    by={(r["name"],r["url"]):r for r in old}
    for r in new_rows: by[(r["name"],r["url"])]=r
    rows=list(by.values())
    rows.sort(key=lambda r:(r["name"],r["url"]))
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=MANIFEST_FIELDS); w.writeheader(); w.writerows(rows)
    logging.info("Manifest: %s (%d rows)",path,len(rows))


def main():
    ap=argparse.ArgumentParser()
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--core",action="store_true")
    g.add_argument("--gaia",action="store_true")
    args=ap.parse_args()
    rows=download_core() if args.core else download_gaia()
    merge_manifest(rows)
    failed=sum(1 for r in rows if str(r.get("status","")).startswith("failed"))
    logging.info("Finished: %d records, %d failed/fallback",len(rows),failed)
    # Do not fail Stage 01 merely because a preferred ASCII endpoint is blocked;
    # Stage 02 can parse saved HTML. Fail only if every requested source failed.
    good=sum(1 for r in rows if not str(r.get("status","")).startswith("failed"))
    return 0 if good else 2

if __name__=="__main__":
    raise SystemExit(main())
