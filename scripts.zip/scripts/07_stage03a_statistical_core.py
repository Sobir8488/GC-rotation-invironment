from __future__ import annotations
import argparse, json, math
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr, rankdata, pearsonr

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"
OUT.mkdir(parents=True,exist_ok=True)

def bh_adjust(p):
    p=np.asarray(p,float)
    q=np.full_like(p,np.nan)
    good=np.isfinite(p)
    pg=p[good]
    if not len(pg): return q
    order=np.argsort(pg)
    ranked=pg[order]
    m=len(ranked)
    raw=ranked*m/np.arange(1,m+1)
    adj=np.minimum.accumulate(raw[::-1])[::-1]
    adj=np.clip(adj,0,1)
    back=np.empty(m)
    back[order]=adj
    q[good]=back
    return q

def corr_row(df,response,descriptor,family,role="primary"):
    d=df[[response,descriptor]].replace([np.inf,-np.inf],np.nan).dropna()
    if len(d)<3:
        return dict(family=family,role=role,response=response,descriptor=descriptor,N=len(d),
                    rho_s=np.nan,p=np.nan)
    rho,p=spearmanr(d[response],d[descriptor])
    return dict(family=family,role=role,response=response,descriptor=descriptor,N=len(d),
                rho_s=float(rho),p=float(p))

def partial_spearman(df,response,descriptor,controls):
    cols=[response,descriptor]+controls
    d=df[cols].replace([np.inf,-np.inf],np.nan).dropna()
    n=len(d)
    if n < max(8,len(controls)+4):
        return n,np.nan,np.nan
    arr=d.to_numpy(float)
    ranks=np.column_stack([rankdata(arr[:,j],method="average") for j in range(arr.shape[1])])
    y=ranks[:,0]; x=ranks[:,1]; C=ranks[:,2:]
    # Standardize controls; drop zero-variance columns.
    if C.size:
        keep=np.nanstd(C,axis=0)>0
        C=C[:,keep]
    if C.size:
        C=(C-C.mean(axis=0))/C.std(axis=0,ddof=0)
        X=np.column_stack([np.ones(n),C])
        ry=y-X@np.linalg.lstsq(X,y,rcond=None)[0]
        rx=x-X@np.linalg.lstsq(X,x,rcond=None)[0]
    else:
        ry=y-y.mean(); rx=x-x.mean()
    rho,p=pearsonr(ry,rx)
    return n,float(rho),float(p)

def bootstrap_spearman(x,y,nres,seed,conf):
    x=np.asarray(x,float); y=np.asarray(y,float)
    good=np.isfinite(x)&np.isfinite(y)
    x=x[good]; y=y[good]
    n=len(x)
    if n<3:
        return {}
    rng=np.random.default_rng(seed)
    vals=np.empty(nres,float)
    for i in range(nres):
        idx=rng.integers(0,n,n)
        vals[i]=spearmanr(x[idx],y[idx]).statistic
    alpha=(1-conf)/2
    lo,med,hi=np.nanquantile(vals,[alpha,0.5,1-alpha])
    return {
        "N":n,"n_resamples":nres,"seed":seed,
        "rho_boot_median":float(med),
        "rho_ci_low":float(lo),"rho_ci_high":float(hi),
        "frac_rho_lt_0":float(np.mean(vals<0)),
        "frac_rho_gt_0":float(np.mean(vals>0)),
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config"); args=ap.parse_args()
    cfg=yaml.safe_load((ROOT/args.config).read_text(encoding="utf-8"))
    master=pd.read_csv(OUT/"stage02c_master_with_los.csv")
    fits=pd.read_csv(OUT/"stage02c_los_rotation_catalog.csv")

    # Preserve only parser-valid, quality-selected fits and attach strict columns.
    use=fits.loc[fits["parser_ok"].fillna(False).astype(bool)].copy()
    # Attach both primary radial-coverage diagnostics and strict-layer fields
    # from the Stage 02C fit catalogue. stage02c_master_with_los.csv intentionally
    # contains only a compact primary subset and therefore does not carry
    # primary_r_p10_arcsec / primary_r_p90_arcsec.
    fit_cols=[
        "cluster_key",
        "primary_r_p10_arcsec","primary_r_p50_arcsec","primary_r_p90_arcsec",
        "strict_quality","strict_a_rot_los_kms","strict_n_fit",
        "strict_angular_bins_occupied","strict_max_angular_gap_deg",
        "strict_r_p10_arcsec","strict_r_p50_arcsec","strict_r_p90_arcsec"
    ]
    extra=use[[c for c in fit_cols if c in use.columns]].copy()
    if extra["cluster_key"].duplicated().any():
        dup=extra.loc[extra["cluster_key"].duplicated(keep=False),"cluster_key"].tolist()
        raise RuntimeError("Duplicate cluster_key rows in Stage 02C fit catalogue: "+repr(dup[:20]))
    df=master.merge(extra,on="cluster_key",how="left",suffixes=("","_fitmerge"))

    # Primary quality is already represented by non-null primary Arot in stage02c_master_with_los.
    df["eccentricity"]=(df["r_apo_kpc"]-df["r_peri_kpc"])/(df["r_apo_kpc"]+df["r_peri_kpc"])

    def lg(s):
        x=pd.to_numeric(s,errors="coerce")
        return np.where(x>0,np.log10(x),np.nan)

    df["log_mass_msun"]=lg(df["mass_msun"])
    df["log_rh_l_pc"]=lg(df["rh_l_pc"])
    df["log_sig0_kms"]=lg(df["sig0_kms"])
    df["log_n_fit"]=lg(df["primary_n_fit"])
    if "primary_r_p10_arcsec" in df and "primary_r_p90_arcsec" in df:
        p10=pd.to_numeric(df["primary_r_p10_arcsec"],errors="coerce")
        p90=pd.to_numeric(df["primary_r_p90_arcsec"],errors="coerce")
        span=p90 / np.maximum(p10,1e-6)
        # Treat non-finite/non-positive coverage ratios as missing; do not silently
        # coerce them to a finite control value.
        df["log_radial_span"]=np.where(np.isfinite(span)&(span>0),np.log10(span),np.nan)
    else:
        df["log_radial_span"]=np.nan
    df["angular_bins_occupied"]=pd.to_numeric(df["primary_angular_bins_occupied"],errors="coerce")
    df["max_angular_gap_deg"]=pd.to_numeric(df["primary_max_angular_gap_deg"],errors="coerce")

    # Direct FDR families.
    rows=[]
    for fam,fcfg in cfg["families"].items():
        resp=fcfg["response"]
        # strict layer must be strict-quality
        dbase=df.copy()
        if fam=="strict_sensitivity" and "strict_quality" in dbase:
            dbase=dbase.loc[dbase["strict_quality"].fillna(False).astype(bool)].copy()
        for desc in fcfg["descriptors"]:
            rows.append(corr_row(dbase,resp,desc,fam,
                                 role="primary" if fam=="direct_environment" else "sensitivity"))
    ledger=pd.DataFrame(rows)
    ledger["q_FDR"]=np.nan
    for fam,idx in ledger.groupby("family").groups.items():
        ledger.loc[idx,"q_FDR"]=bh_adjust(ledger.loc[idx,"p"].to_numpy(float))
    ledger["selected_q_lt_0p05"]=ledger["q_FDR"]<float(cfg["decision"]["fdr_alpha"])
    ledger.to_csv(OUT/"stage03a_statistical_ledger.csv",index=False)

    # Controlled primary pericentre family.
    # Record control-column availability so an accidental all-NaN control can
    # never masquerade as a scientific null result.
    control_availability=[]
    for cname in sorted(set(sum(cfg["controls"].values(), []))):
        vals=pd.to_numeric(df.get(cname),errors="coerce")
        control_availability.append({
            "control":cname,
            "N_finite":int(np.isfinite(vals).sum()),
            "fraction_finite":float(np.isfinite(vals).mean())
        })
    pd.DataFrame(control_availability).to_csv(
        OUT/"stage03a_control_availability.csv",index=False
    )

    controls=[]
    response=cfg["primary_response"]; descriptor="r_peri_kpc"
    for name,ctrls in cfg["controls"].items():
        n,rho,p=partial_spearman(df,response,descriptor,ctrls)
        controls.append({
            "family":"controlled_direct_pericentre",
            "control_set":name,"response":response,"descriptor":descriptor,
            "controls":";".join(ctrls),"N":n,"rho_partial_s":rho,"p":p
        })
    ctl=pd.DataFrame(controls)
    ctl["q_FDR"]=bh_adjust(ctl["p"].to_numpy(float))
    ctl["selected_q_lt_0p05"]=ctl["q_FDR"]<float(cfg["decision"]["fdr_alpha"])
    ctl.to_csv(OUT/"stage03a_controlled_ledger.csv",index=False)

    # Bootstrap primary and strict pericentre relations.
    boots=[]
    bc=cfg["bootstrap"]
    for label,resp,qualcol,offset in [
        ("primary","primary_a_rot_los_kms",None,0),
        ("strict","strict_a_rot_los_kms","strict_quality",1)
    ]:
        d=df.copy()
        if qualcol and qualcol in d:
            d=d.loc[d[qualcol].fillna(False).astype(bool)]
        dd=d[[resp,"r_peri_kpc"]].dropna()
        b=bootstrap_spearman(dd[resp],dd["r_peri_kpc"],int(bc["n_resamples"]),
                            int(bc["seed"])+offset,float(bc["confidence"]))
        b.update({"layer":label,"response":resp,"descriptor":"r_peri_kpc"})
        boots.append(b)
    bootdf=pd.DataFrame(boots)
    bootdf.to_csv(OUT/"stage03a_bootstrap_summary.csv",index=False)

    # Human-readable summary.
    prim=ledger[(ledger.family=="direct_environment")&(ledger.descriptor=="r_peri_kpc")].iloc[0]
    strict=ledger[(ledger.family=="strict_sensitivity")&(ledger.descriptor=="r_peri_kpc")].iloc[0]
    lines=[
        "JAA_REPRO_REBUILD STAGE 03A SUMMARY",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),"",
        "PRIMARY DIRECT-ENVIRONMENT FAMILY (BH-FDR across 4 orbital descriptors)",
        f"Arot_LOS vs R_peri: N={int(prim.N)}, rho_S={prim.rho_s:.6g}, p={prim.p:.6g}, q_FDR={prim.q_FDR:.6g}, selected={bool(prim.selected_q_lt_0p05)}",
        "",
        "STRICT MEMBERSHIP SENSITIVITY FAMILY",
        f"strict Arot_LOS vs R_peri: N={int(strict.N)}, rho_S={strict.rho_s:.6g}, p={strict.p:.6g}, q_FDR={strict.q_FDR:.6g}, selected={bool(strict.selected_q_lt_0p05)}",
        "",
        "CONTROLLED DIRECT-PERICENTRE TESTS",
    ]
    for _,r in ctl.iterrows():
        lines.append(f"{r.control_set}: N={int(r.N)}, rho_partial={r.rho_partial_s:.6g}, p={r.p:.6g}, q_FDR={r.q_FDR:.6g}, selected={bool(r.selected_q_lt_0p05)}")
    lines += ["","BOOTSTRAP"]
    for _,r in bootdf.iterrows():
        lines.append(f"{r.layer}: N={int(r.N)}, median rho={r.rho_boot_median:.6g}, 95% CI=[{r.rho_ci_low:.6g},{r.rho_ci_high:.6g}], P(rho<0)={r.frac_rho_lt_0:.6g}")
    lines += ["","CONTROL-COLUMN AVAILABILITY"]
    for r in control_availability:
        lines.append(f"{r['control']}: N_finite={r['N_finite']}, fraction={r['fraction_finite']:.3f}")
    bad_controls=[r for r in control_availability if r["N_finite"] < int(cfg["decision"]["min_pair_n"])]
    if bad_controls:
        lines += ["",
                  "WARNING: one or more control columns remain too incomplete for controlled inference:",
                  ", ".join(r["control"] for r in bad_controls)]
    else:
        lines += ["","All configured control columns have sufficient finite coverage."]

    lines += [
        "",
        "INTERPRETATION RULE",
        "Raw/FDR selection and controlled selection are reported separately.",
        "A raw selected association is not converted into a causal claim if full controls are not selected.",
        "No historical coefficient is used as a fitting target."
    ]
    (OUT/"stage03a_summary.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print("JAA_REPRO_REBUILD STAGE 03A SUMMARY")
    print(lines[3]); print(lines[4]); print("")
    print(lines[6]); print(lines[7]); print("")
    print("Controlled rows written:",len(ctl))
    print("Bootstrap rows written:",len(bootdf))
    print("")
    print("SEND BACK:")
    print("  outputs\\stage03a_summary.txt")
    print("  outputs\\stage03a_statistical_ledger.csv")
    print("  outputs\\stage03a_controlled_ledger.csv")
    print("  outputs\\stage03a_bootstrap_summary.csv")

if __name__=="__main__":
    main()
