from __future__ import annotations
import csv, hashlib, json, re, zipfile
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/"data"/"raw"; OUT=ROOT/"outputs"; OUT.mkdir(exist_ok=True)


def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()


def line_count(path):
    if path.suffix.lower() in {".zip"}: return None
    try:
        with open(path,"rb") as f: return sum(1 for _ in f)
    except Exception: return None


def sniff_html_tables(path):
    try:
        tables=pd.read_html(path)
        return len(tables), max((len(t) for t in tables), default=0)
    except Exception:
        return 0,0

rows=[]
for p in sorted(RAW.rglob("*")):
    if not p.is_file(): continue
    item={
        "file":str(p.relative_to(ROOT)),"bytes":p.stat().st_size,"sha256":sha256(p),
        "line_count":line_count(p),"html_tables":"","largest_html_table_rows":"","zip_members":"","status":"OK"
    }
    if p.suffix.lower()==".html":
        n,m=sniff_html_tables(p); item["html_tables"]=n; item["largest_html_table_rows"]=m
        if n==0: item["status"]="WARN_NO_TABLES"
    if p.suffix.lower()==".zip":
        try:
            with zipfile.ZipFile(p) as z: item["zip_members"]=len(z.namelist())
        except Exception: item["status"]="BAD_ZIP"
    rows.append(item)

pd.DataFrame(rows).to_csv(OUT/"input_audit.csv",index=False)

# Reported manuscript checkpoint ledger: these values are NOT final rebuilt results.
ledger=[
 dict(family="external_validation",relation="Arot_LOS vs Arot_PM_lit",N=60,rho_s=0.6488,p=2.1e-8,q_fdr=8.3e-8,value_status="reported_exact",note="primary external validation"),
 dict(family="external_validation",relation="logTphi_peri vs Arot_PM",N=62,rho_s=-0.3352,p=7.7e-3,q_fdr=0.0155,value_status="mixed",note="p reconstructed in polished draft; must be recomputed"),
 dict(family="direct_rotation_environment",relation="Arot_LOS vs r_peri",N=138,rho_s=-0.2988,p=3.70e-4,q_fdr=0.0111,value_status="reported_exact",note="primary environmental relation"),
 dict(family="direct_rotation_environment",relation="log(1+Arot_LOS) vs log r_peri",N=165,rho_s=-0.240,p=1.9e-3,q_fdr=0.02,value_status="reported_approx",note="consistency sample"),
 dict(family="potential_scaling_raw",relation="logTphi_peri vs Arot_LOS",N=138,rho_s=0.299,p=3.7e-4,q_fdr=0.0059,value_status="reported_mixed",note="recompute from new explicit potential"),
 dict(family="potential_scaling_raw",relation="log fJ_phi_peri vs log(1+Arot_LOS)",N=167,rho_s=-0.259,p=7.3e-4,q_fdr=0.0078,value_status="reported_approx",note="recompute from new explicit potential"),
 dict(family="potential_scaling_raw",relation="log Tphi_strength vs log(1+Arot_LOS)",N=167,rho_s=-0.277,p=2.9e-4,q_fdr=0.0059,value_status="reported_approx",note="recompute from new explicit potential"),
 dict(family="potential_scaling_controlled",relation="controlled potential scaling family",N="",rho_s="",p="",q_fdr="",value_status="missing_historical",note="must be regenerated coefficient-by-coefficient; qualitative 'weak' prohibited"),
 dict(family="differential_rotation",relation="Dvec_LOS vs global direct rotation",N=59,rho_s=-0.421,p=1.0e-3,q_fdr="",value_status="q_missing_historical",note="secondary; exact q must be regenerated"),
 dict(family="scalar_dilution",relation="Balanced EKMI dilution vs log r_peri",N="",rho_s="",p="",q_fdr="",value_status="reported_derived",note="Delta_dil=0.230"),
 dict(family="scalar_dilution",relation="Full EKMI dilution vs log r_peri",N="",rho_s="",p="",q_fdr="",value_status="reported_derived",note="Delta_dil=0.211"),
 dict(family="scalar_dilution",relation="Rotation EKMI dilution vs log r_peri",N="",rho_s="",p="",q_fdr="",value_status="reported_derived",note="Delta_dil=0.209"),
]
pd.DataFrame(ledger).to_csv(OUT/"reported_manuscript_ledger.csv",index=False)

# Summary
manifest=OUT/"provenance_manifest.csv"
manifest_rows=[]
if manifest.exists():
    manifest_rows=list(csv.DictReader(open(manifest,encoding="utf-8")))
summary=[]
summary.append("JAA_REPRO_REBUILD STAGE 01 AUDIT")
summary.append("Generated UTC: "+datetime.now(timezone.utc).isoformat())
summary.append(f"Raw files present: {len(rows)}")
summary.append(f"Manifest rows: {len(manifest_rows)}")
summary.append(f"Audit OK files: {sum(r['status']=='OK' for r in rows)}")
summary.append(f"Audit warnings/errors: {sum(r['status']!='OK' for r in rows)}")
summary.append("")
summary.append("NON-NEGOTIABLE NEXT-STAGE TARGETS")
summary.append("1. Recompute LOS rotation; do not fit toward manuscript checkpoints.")
summary.append("2. Generate complete controlled-statistics rows with N, rho_s, p, q_FDR.")
summary.append("3. Recompute differential-rotation q_FDR.")
summary.append("4. Use explicit potential_models.yaml; label it as a new sensitivity family.")
summary.append("5. Regenerate every statistical figure from machine-readable result tables.")
summary.append("6. Deposit only the final rebuilt package and then insert the new repository DOI.")
(OUT/"stage01_summary.txt").write_text("\n".join(summary)+"\n",encoding="utf-8")
print("\n".join(summary))
