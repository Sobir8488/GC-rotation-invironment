from __future__ import annotations

import argparse
import importlib.util
import io
import math
import re
import zipfile
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr, rankdata, pearsonr

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/"data"/"raw"
OUT=ROOT/"outputs"
OUT.mkdir(parents=True, exist_ok=True)
G=4.300917270036279e-6  # kpc (km/s)^2 / Msun

def norm_name(x):
    s=re.sub(r"[^A-Z0-9]+","",str(x).upper())
    aliases={
        "47TUC":"NGC104","OMEGACEN":"NGC5139","M54":"NGC6715",
        "M5":"NGC5904","M3":"NGC5272","M13":"NGC6205","M15":"NGC7078",
        "M2":"NGC7089","M22":"NGC6656","M92":"NGC6341","M62":"NGC6266"
    }
    return aliases.get(s,s)

def bh_adjust(p):
    p=np.asarray(p,float)
    q=np.full_like(p,np.nan)
    good=np.isfinite(p)
    pg=p[good]
    if not len(pg): return q
    order=np.argsort(pg)
    ranked=pg[order]
    m=len(ranked)
    raw=ranked*m/np.arange(1,m+1)
    adj=np.minimum.accumulate(raw[::-1])[::-1]
    back=np.empty(m); back[order]=np.clip(adj,0,1)
    q[good]=back
    return q

def corr(df,x,y,family,variant="",role=""):
    d=df[[x,y]].replace([np.inf,-np.inf],np.nan).dropna()
    if len(d)<3:
        return dict(family=family,variant=variant,role=role,x=x,y=y,N=len(d),
                    rho_s=np.nan,p=np.nan)
    r,p=spearmanr(d[x],d[y])
    return dict(family=family,variant=variant,role=role,x=x,y=y,N=len(d),
                rho_s=float(r),p=float(p))

def partial_spearman(df,x,y,controls):
    cols=[x,y]+controls
    d=df[cols].replace([np.inf,-np.inf],np.nan).dropna()
    n=len(d)
    if n < max(8,len(controls)+4): return n,np.nan,np.nan
    A=d.to_numpy(float)
    R=np.column_stack([rankdata(A[:,j]) for j in range(A.shape[1])])
    rx,ry=R[:,0],R[:,1]
    C=R[:,2:]
    if C.size:
        keep=np.nanstd(C,axis=0)>0
        C=C[:,keep]
    if C.size:
        C=(C-C.mean(0))/C.std(0,ddof=0)
        X=np.column_stack([np.ones(n),C])
        rx=rx-X@np.linalg.lstsq(X,rx,rcond=None)[0]
        ry=ry-X@np.linalg.lstsq(X,ry,rcond=None)[0]
    return n,*map(float,pearsonr(rx,ry))

# ------------------------------------------------------------------
# Explicit potential sensitivity family
# ------------------------------------------------------------------
def phi_hernquist(x,y,z,m,c):
    r=math.sqrt(x*x+y*y+z*z)
    return -G*m/(r+c)

def phi_mn(x,y,z,m,a,b):
    R2=x*x+y*y
    B=a+math.sqrt(z*z+b*b)
    return -G*m/math.sqrt(R2+B*B)

def phi_nfw(x,y,z,m,rs):
    r=math.sqrt(x*x+y*y+z*z)
    if r < 1e-10:
        return -G*m/rs
    return -G*m*math.log1p(r/rs)/r

def make_model(cfg,scale):
    b=cfg["base"]
    return {
        "nucleus":dict(m=float(b["nucleus"]["mass_msun"])*scale,
                       c=float(b["nucleus"]["scale_kpc"])),
        "bulge":dict(m=float(b["bulge"]["mass_msun"])*scale,
                    c=float(b["bulge"]["scale_kpc"])),
        "disk":dict(m=float(b["disk"]["mass_msun"])*scale,
                   a=float(b["disk"]["a_kpc"]),b=float(b["disk"]["b_kpc"])),
        "halo":dict(m=float(b["halo"]["mass_msun"])*scale,
                   rs=float(b["halo"]["rs_kpc"]))
    }

def phi_total(pos,model):
    x,y,z=map(float,pos)
    return (
        phi_hernquist(x,y,z,**model["nucleus"])
        + phi_hernquist(x,y,z,**model["bulge"])
        + phi_mn(x,y,z,**model["disk"])
        + phi_nfw(x,y,z,**model["halo"])
    )

def hessian_numeric(R,model,relstep,minstep):
    p=np.array([R,0.0,0.0],float)
    h=max(minstep,abs(R)*relstep)
    H=np.zeros((3,3),float)
    f0=phi_total(p,model)
    for i in range(3):
        ei=np.zeros(3); ei[i]=h
        H[i,i]=(phi_total(p+ei,model)-2*f0+phi_total(p-ei,model))/h**2
        for j in range(i+1,3):
            ej=np.zeros(3); ej[j]=h
            H[i,j]=(phi_total(p+ei+ej,model)-phi_total(p+ei-ej,model)
                    -phi_total(p-ei+ej,model)+phi_total(p-ei-ej,model))/(4*h*h)
            H[j,i]=H[i,j]
    # radial first derivative and curvature
    ex=np.array([h,0,0])
    dphi=(phi_total(p+ex,model)-phi_total(p-ex,model))/(2*h)
    d2=H[0,0]
    return H,dphi,d2,h

def potential_layer(df,pcfg):
    rows=[]
    params=[]
    for vname,scale in pcfg["mass_scale_variants"].items():
        model=make_model(pcfg,float(scale))
        params.extend([
            dict(variant=vname,mass_scale=scale,component="nucleus",type="Hernquist",
                 mass_msun=model["nucleus"]["m"],scale1_kpc=model["nucleus"]["c"],scale2_kpc=np.nan),
            dict(variant=vname,mass_scale=scale,component="bulge",type="Hernquist",
                 mass_msun=model["bulge"]["m"],scale1_kpc=model["bulge"]["c"],scale2_kpc=np.nan),
            dict(variant=vname,mass_scale=scale,component="disk",type="MiyamotoNagai",
                 mass_msun=model["disk"]["m"],scale1_kpc=model["disk"]["a"],scale2_kpc=model["disk"]["b"]),
            dict(variant=vname,mass_scale=scale,component="halo",type="NFW",
                 mass_msun=model["halo"]["m"],scale1_kpc=model["halo"]["rs"],scale2_kpc=np.nan),
        ])
        for _,r in df.iterrows():
            R=float(r["r_peri_kpc"]) if np.isfinite(r.get("r_peri_kpc",np.nan)) else np.nan
            M=float(r["mass_msun"]) if np.isfinite(r.get("mass_msun",np.nan)) else np.nan
            rh=float(r["rh_l_pc"]) if np.isfinite(r.get("rh_l_pc",np.nan)) else np.nan
            if not (np.isfinite(R) and R>0 and np.isfinite(M) and M>0 and np.isfinite(rh) and rh>0):
                continue
            H,dphi,d2,h=hessian_numeric(
                R,model,float(pcfg["finite_difference"]["relative_step"]),
                float(pcfg["finite_difference"]["minimum_step_kpc"])
            )
            eig=np.linalg.eigvalsh(H)
            lam=float(np.max(np.abs(eig)))
            omega2=float(dphi/R)
            denom=omega2-d2
            rj=(G*M/denom)**(1/3) if np.isfinite(denom) and denom>0 else np.nan
            rhk=rh/1000.0
            fJ=rhk/rj if np.isfinite(rj) and rj>0 else np.nan
            T=lam*rhk**3/(G*M)
            rows.append({
                "cluster":r["cluster"],"cluster_key":r["cluster_key"],"variant":vname,
                "r_peri_kpc":R,"mass_msun":M,"rh_l_pc":rh,
                "lambda_max_abs_kms2_kpc2":lam,"omega2_kms2_kpc2":omega2,
                "d2phi_dR2_kms2_kpc2":d2,"jacobi_local_kpc":rj,
                "fJ_peri":fJ,"Tphi_peri":T,"fd_step_kpc":h
            })
    return pd.DataFrame(rows),pd.DataFrame(params)

# ------------------------------------------------------------------
# Differential rotation from repaired Stage 02C parser
# ------------------------------------------------------------------
def load_stage02c_module():
    p=ROOT/"scripts"/"06_stage02c_repair_rv_parser.py"
    spec=importlib.util.spec_from_file_location("stage02cmod",p)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def half_quality(f,dcfg):
    return bool(
        f.get("fit_ok",False)
        and f.get("n_fit",0)>=int(dcfg["min_stars_per_half"])
        and f.get("angular_bins_occupied",0)>=int(dcfg["min_occupied_bins_per_half"])
        and f.get("max_angular_gap_deg",360)<=float(dcfg["max_gap_deg_per_half"])
    )

def build_differential(master,fits,cfg):
    mod=load_stage02c_module()
    c02=yaml.safe_load((ROOT/"config"/"stage02c_analysis.yaml").read_text(encoding="utf-8"))
    dcfg=cfg["differential_rotation"]
    fitkeys=set(fits.loc[fits["parser_ok"].fillna(False).astype(bool),"cluster_key"].astype(str))
    rows=[]
    for i,path in enumerate(sorted((RAW/"rv_by_cluster").glob("*.txt")),1):
        # Resolve using Stage 02C catalogue, which already passed filename/coordinate matching.
        hit=fits.loc[fits["rv_file"]==path.name]
        if len(hit)!=1: continue
        key=str(hit.iloc[0]["cluster_key"])
        if key not in fitkeys: continue
        m=master.loc[master["cluster_key"].astype(str)==key]
        if len(m)!=1: continue
        mr=m.iloc[0]
        ra0=float(mr["ra_deg"]); dec0=float(mr["dec_deg"])
        stars,modes=mod.parse_file(path,ra0,dec0)
        sel=mod.robust_select(stars,c02,strict=False)
        if len(sel)<2*int(dcfg["min_stars_per_half"]): continue
        radius=pd.to_numeric(sel["dcen_arcsec_computed"],errors="coerce")
        good=np.isfinite(radius)
        sel=sel.loc[good].copy()
        if len(sel)<2*int(dcfg["min_stars_per_half"]): continue
        split=float(np.nanquantile(sel["dcen_arcsec_computed"],float(dcfg["split_quantile"])))
        inner=sel.loc[sel["dcen_arcsec_computed"]<=split].copy()
        outer=sel.loc[sel["dcen_arcsec_computed"]>split].copy()
        fi=mod.fit_rot(inner,ra0,dec0,c02)
        fo=mod.fit_rot(outer,ra0,dec0,c02)
        qi=half_quality(fi,dcfg); qo=half_quality(fo,dcfg)
        dvec=np.nan
        if qi and qo:
            ai=float(fi["a_sin_kms"]); bi=float(fi["b_cos_kms"])
            ao=float(fo["a_sin_kms"]); bo=float(fo["b_cos_kms"])
            Ain=math.hypot(ai,bi); Aout=math.hypot(ao,bo)
            dvec=math.hypot(ao-ai,bo-bi)/(Aout+Ain+1e-12)
        rows.append({
            "cluster":mr["cluster"],"cluster_key":key,"n_total":len(sel),
            "split_arcsec":split,"n_inner":len(inner),"n_outer":len(outer),
            "inner_quality":qi,"outer_quality":qo,
            "Ain_kms":fi.get("a_rot_los_kms",np.nan),
            "Aout_kms":fo.get("a_rot_los_kms",np.nan),
            "phi_in_deg":fi.get("phi_rot_deg",np.nan),
            "phi_out_deg":fo.get("phi_rot_deg",np.nan),
            "inner_bins":fi.get("angular_bins_occupied",np.nan),
            "outer_bins":fo.get("angular_bins_occupied",np.nan),
            "inner_gap_deg":fi.get("max_angular_gap_deg",np.nan),
            "outer_gap_deg":fo.get("max_angular_gap_deg",np.nan),
            "Dvec_LOS":dvec
        })
        if i%40==0:
            print(f"Differential pass progress: {i}/161")
    return pd.DataFrame(rows)

# ------------------------------------------------------------------
# Gaia EDR3 PM profile discovery / safe parsing
# ------------------------------------------------------------------
def numeric_matrix(lines):
    rows=[]
    for ln in lines:
        s=ln.strip()
        if not s or s.startswith(("#","!","%",";")): continue
        toks=re.split(r"\s+",s)
        vals=[]
        ok=True
        for t in toks:
            try: vals.append(float(t.replace("D","E").replace("d","e")))
            except Exception:
                ok=False; break
        if ok and len(vals)>=2: rows.append(vals)
    if not rows: return None
    widths=pd.Series([len(r) for r in rows]).value_counts()
    w=int(widths.index[0])
    rows=[r for r in rows if len(r)==w]
    return np.asarray(rows,float) if rows else None

def find_rotation_col_from_header(lines,ncol):
    # Only accept explicit textual identification. This intentionally avoids
    # guessing a column based only on position or numerical appearance.
    candidates=[]
    for ln in lines[:40]:
        low=ln.lower()
        if "rot" not in low and "mu_t" not in low and "mut" not in low:
            continue
        clean=re.sub(r"^[#!%;\s]+","",ln.strip())
        toks=re.split(r"\s+",clean)
        # remove obvious units-only tokens
        if len(toks)==ncol:
            for j,t in enumerate(toks):
                tl=t.lower()
                if "rot" in tl or "mu_t" in tl or "mut" in tl:
                    candidates.append(j)
    return candidates[0] if len(set(candidates))==1 else None

def pm_profile_layer(master,cfg):
    zpath=ROOT/cfg["external_validation"]["gaia_zip"]
    schema=[]
    amps=[]
    if not zpath.exists():
        return pd.DataFrame(), "GAIA ZIP MISSING", pd.DataFrame()
    with zipfile.ZipFile(zpath) as z:
        names=[n for n in z.namelist() if not n.endswith("/")]
        readme_name=next((n for n in names if Path(n).name.lower()=="!readme.txt"),None)
        readme=z.read(readme_name).decode("utf-8",errors="replace") if readme_name else ""
        profile_names=[n for n in names if "profile" in n.lower()]
        if not profile_names:
            profile_names=[n for n in names
                           if n!=readme_name and "catalog" not in n.lower()]
        for n in profile_names:
            txt=z.read(n).decode("utf-8",errors="replace")
            lines=txt.splitlines()
            mat=numeric_matrix(lines)
            ncol=mat.shape[1] if mat is not None else 0
            rotcol=find_rotation_col_from_header(lines,ncol) if mat is not None else None
            schema.append({
                "member":n,"n_numeric_rows":0 if mat is None else len(mat),
                "n_numeric_cols":ncol,"rotation_col_explicit":rotcol,
                "sample":" || ".join(x.strip() for x in lines[:8])[:1800]
            })
            if mat is None or rotcol is None or len(mat)<int(cfg["external_validation"]["min_profile_points"]):
                continue
            mu=mat[:,rotcol]
            if not np.isfinite(mu).any(): continue
            stem=Path(n).stem
            key=norm_name(stem)
            m=master.loc[master["cluster_key"].astype(str).map(norm_name)==key]
            if len(m)!=1: continue
            dist=float(m.iloc[0]["r_sun_kpc"])
            amp_mu=float(np.nanmax(np.abs(mu)))
            amps.append({
                "cluster":m.iloc[0]["cluster"],"cluster_key":m.iloc[0]["cluster_key"],
                "profile_member":n,"rotation_col_index":rotcol,
                "Arot_PM_masyr":amp_mu,"r_sun_kpc":dist,
                "Arot_PM_kms":amp_mu*float(cfg["external_validation"]["km_s_per_masyr_kpc"])*dist,
                "n_profile_points":len(mat)
            })
        report=[
            "JAA STAGE 03B GAIA PM PROFILE SCHEMA",
            f"ZIP members: {len(names)}",
            f"Profile candidates: {len(profile_names)}",
            f"Profiles with explicitly recognized rotation column: {len(amps)}",
            "",
            "README EXCERPT (lines mentioning profile/rotation):"
        ]
        rel=[ln for ln in readme.splitlines() if ("profile" in ln.lower() or "rot" in ln.lower())]
        report += rel[:80]
        report += ["","FIRST 20 PROFILE CANDIDATES:"]
        for r in schema[:20]:
            report.append(str(r))
    return pd.DataFrame(amps),"\n".join(report)+"\n",pd.DataFrame(schema)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config"); args=ap.parse_args()
    cfg=yaml.safe_load((ROOT/args.config).read_text(encoding="utf-8"))
    master=pd.read_csv(OUT/"stage02c_master_with_los.csv")
    fits=pd.read_csv(OUT/"stage02c_los_rotation_catalog.csv")
    master["eccentricity"]=(master["r_apo_kpc"]-master["r_peri_kpc"])/(master["r_apo_kpc"]+master["r_peri_kpc"])
    use=master.dropna(subset=["primary_a_rot_los_kms"]).copy()

    # ---------------- external layers ----------------
    external=[]
    # Literature consistency layer from structural A_Rot. This is NOT labelled
    # independent because the provenance may overlap with the RV compilation.
    lit=use[["primary_a_rot_los_kms","a_rot_catalog_kms"]].dropna()
    if len(lit)>=3:
        r,p=spearmanr(lit.primary_a_rot_los_kms,lit.a_rot_catalog_kms)
    else: r=p=np.nan
    external.append({
        "layer":"catalogue_literature_consistency","independence_status":"not_assumed_independent",
        "N":len(lit),"rho_s":r,"p":p,"q_FDR":p,
        "definition":"Baumgardt structural-table A_Rot vs rebuilt star-level LOS A_Rot"
    })

    pm,pm_report,pm_schema=pm_profile_layer(master,cfg)
    (OUT/"stage03b_gaia_profile_schema.txt").write_text(pm_report,encoding="utf-8")
    pm_schema.to_csv(OUT/"stage03b_gaia_profile_schema.csv",index=False)
    pm.to_csv(OUT/"stage03b_gaia_pm_amplitudes.csv",index=False)
    if len(pm):
        vv=use.merge(pm[["cluster_key","Arot_PM_kms"]],on="cluster_key",how="inner")
        if len(vv)>=3:
            r,p=spearmanr(vv.primary_a_rot_los_kms,vv.Arot_PM_kms)
        else:r=p=np.nan
        external.append({
            "layer":"Gaia_EDR3_PM_profile_validation","independence_status":"independent_PM_channel",
            "N":len(vv),"rho_s":r,"p":p,"q_FDR":p,
            "definition":"max |published PM rotation profile| converted to km/s vs rebuilt LOS A_Rot"
        })
    else:
        external.append({
            "layer":"Gaia_EDR3_PM_profile_validation","independence_status":"schema_not_safely_resolved",
            "N":0,"rho_s":np.nan,"p":np.nan,"q_FDR":np.nan,
            "definition":"No positional-column guessing allowed; inspect stage03b_gaia_profile_schema.txt"
        })
    ext=pd.DataFrame(external)
    ext.to_csv(OUT/"stage03b_external_validation_ledger.csv",index=False)

    # ---------------- potential layer ----------------
    pcfg=cfg["potential_family"]
    pot,params=potential_layer(use,pcfg)
    params["family_label"]=pcfg["label"]
    params["reference_model"]=pcfg["reference_model"]
    params.to_csv(OUT/"stage03b_potential_parameters.csv",index=False)
    pot.to_csv(OUT/"stage03b_potential_cluster_values.csv",index=False)

    # Attach Arot and controls.
    fit_primary=fits.loc[fits["parser_ok"].fillna(False).astype(bool)].copy()
    extra=fit_primary[["cluster_key","primary_n_fit","primary_angular_bins_occupied",
                       "primary_max_angular_gap_deg","primary_r_p10_arcsec","primary_r_p90_arcsec"]]
    d=use.merge(extra,on="cluster_key",how="left",suffixes=("","_fit"))
    d["log_mass_msun"]=np.where(d.mass_msun>0,np.log10(d.mass_msun),np.nan)
    d["log_rh_l_pc"]=np.where(d.rh_l_pc>0,np.log10(d.rh_l_pc),np.nan)
    d["log_sig0_kms"]=np.where(d.sig0_kms>0,np.log10(d.sig0_kms),np.nan)
    d["log_n_fit"]=np.where(d.primary_n_fit>0,np.log10(d.primary_n_fit),np.nan)
    span=d.primary_r_p90_arcsec/np.maximum(d.primary_r_p10_arcsec,1e-6)
    d["log_radial_span"]=np.where(span>0,np.log10(span),np.nan)
    d["angular_bins_occupied"]=d.primary_angular_bins_occupied
    d["max_angular_gap_deg"]=d.primary_max_angular_gap_deg
    d["log1p_Arot"]=np.log10(1.0+d.primary_a_rot_los_kms)

    pled=[]
    cled=[]
    for vname in pcfg["mass_scale_variants"]:
        pv=pot.loc[pot.variant==vname].copy()
        pv["log_lambda_max_peri"]=np.where(pv.lambda_max_abs_kms2_kpc2>0,np.log10(pv.lambda_max_abs_kms2_kpc2),np.nan)
        pv["log_Tphi_peri"]=np.where(pv.Tphi_peri>0,np.log10(pv.Tphi_peri),np.nan)
        pv["log_fJ_peri"]=np.where(pv.fJ_peri>0,np.log10(pv.fJ_peri),np.nan)
        z=d.merge(pv[["cluster_key","log_lambda_max_peri","log_Tphi_peri","log_fJ_peri"]],
                  on="cluster_key",how="inner")
        for x,y in pcfg["raw_relations"]:
            rr=corr(z,x,y,"potential_raw",vname,"raw_physical_reparameterization")
            pled.append(rr)
            n,r,p=partial_spearman(z,x,y,list(pcfg["full_controls"]))
            cled.append({
                "family":"potential_controlled","variant":vname,"x":x,"y":y,
                "controls":";".join(pcfg["full_controls"]),"N":n,
                "rho_partial_s":r,"p":p
            })
    pled=pd.DataFrame(pled)
    pled["q_FDR"]=np.nan
    # FDR within each potential variant's three pre-specified raw relations.
    for v,idx in pled.groupby("variant").groups.items():
        pled.loc[idx,"q_FDR"]=bh_adjust(pled.loc[idx,"p"])
    pled["selected_q_lt_0p05"]=pled.q_FDR<float(cfg["fdr_alpha"])
    pled.to_csv(OUT/"stage03b_potential_ledger.csv",index=False)

    cled=pd.DataFrame(cled)
    cled["q_FDR"]=np.nan
    for v,idx in cled.groupby("variant").groups.items():
        cled.loc[idx,"q_FDR"]=bh_adjust(cled.loc[idx,"p"])
    cled["selected_q_lt_0p05"]=cled.q_FDR<float(cfg["fdr_alpha"])
    cled.to_csv(OUT/"stage03b_controlled_potential_ledger.csv",index=False)

    # ---------------- differential layer ----------------
    diff=build_differential(master,fits,cfg)
    diff.to_csv(OUT/"stage03b_differential_rotation_catalog.csv",index=False)
    dd=master.merge(diff[["cluster_key","Dvec_LOS"]],on="cluster_key",how="inner")
    dl=[]
    for desc in cfg["differential_rotation"]["environment_descriptors"]:
        dl.append(corr(dd,"Dvec_LOS",desc,"differential_environment","fiducial","secondary"))
    # Also record the Dvec-vs-global-Arot diagnostic separately from the environmental FDR family.
    dl.append(corr(dd,"Dvec_LOS","primary_a_rot_los_kms",
                   "differential_vs_global_rotation","fiducial","diagnostic"))
    dl=pd.DataFrame(dl)
    dl["q_FDR"]=np.nan
    idx=dl.index[dl.family=="differential_environment"]
    dl.loc[idx,"q_FDR"]=bh_adjust(dl.loc[idx,"p"])
    # diagnostic single relation gets q=p but is not part of environmental family
    idx2=dl.index[dl.family=="differential_vs_global_rotation"]
    dl.loc[idx2,"q_FDR"]=dl.loc[idx2,"p"]
    dl["selected_q_lt_0p05"]=dl.q_FDR<float(cfg["fdr_alpha"])
    dl.to_csv(OUT/"stage03b_differential_ledger.csv",index=False)

    # ---------------- summary ----------------
    lines=[
        "JAA_REPRO_REBUILD STAGE 03B SUMMARY",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),"",
        "EXTERNAL VALIDATION / CONSISTENCY"
    ]
    for _,r in ext.iterrows():
        lines.append(f"{r.layer}: status={r.independence_status}, N={int(r.N)}, rho={r.rho_s}, p={r.p}, q={r.q_FDR}")
    lines += ["","POTENTIAL FAMILY",
              f"Label: {pcfg['label']}",
              "Light/fiducial/heavy mass scales: "+repr(pcfg["mass_scale_variants"]),
              "This is a NEW documented sensitivity family, not a recovery of the lost MATLAB potentials."]
    for v in pcfg["mass_scale_variants"]:
        lines.append(f"  {v} raw:")
        for _,r in pled.loc[pled.variant==v].iterrows():
            lines.append(f"    {r.x} vs {r.y}: N={int(r.N)}, rho={r.rho_s:.6g}, p={r.p:.6g}, q={r.q_FDR:.6g}, selected={bool(r.selected_q_lt_0p05)}")
        lines.append(f"  {v} controlled:")
        for _,r in cled.loc[cled.variant==v].iterrows():
            lines.append(f"    {r.x} vs {r.y}: N={int(r.N)}, rho_partial={r.rho_partial_s:.6g}, p={r.p:.6g}, q={r.q_FDR:.6g}, selected={bool(r.selected_q_lt_0p05)}")
    lines += ["","DIFFERENTIAL ROTATION",
              f"Finite Dvec clusters: {int(np.isfinite(pd.to_numeric(diff.get('Dvec_LOS'),errors='coerce')).sum()) if len(diff) else 0}"]
    for _,r in dl.iterrows():
        lines.append(f"{r.family}: {r.x} vs {r.y}: N={int(r.N)}, rho={r.rho_s:.6g}, p={r.p:.6g}, q={r.q_FDR:.6g}, selected={bool(r.selected_q_lt_0p05)}")
    lines += ["","INTERPRETATION GUARDRAILS",
              "1. Gaia PM validation is called independent only if the published PM-profile schema is explicitly resolved.",
              "2. The structural-table A_Rot comparison is a consistency layer, not automatically independent.",
              "3. Potential relations are physical reparameterizations unless their controlled family is selected.",
              "4. Differential-environment relations are secondary and are promoted only if their own FDR family is selected.",
              "5. No Stage 03B result is tuned toward historical manuscript coefficients."]
    (OUT/"stage03b_summary.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print("JAA_REPRO_REBUILD STAGE 03B SUMMARY")
    print(f"External ledger rows:            {len(ext)}")
    print(f"Potential raw rows:              {len(pled)}")
    print(f"Potential controlled rows:       {len(cled)}")
    print(f"Differential catalogue rows:     {len(diff)}")
    print(f"Finite Dvec clusters:            {int(np.isfinite(pd.to_numeric(diff.get('Dvec_LOS'),errors='coerce')).sum()) if len(diff) else 0}")
    pmrow=ext.loc[ext.layer=="Gaia_EDR3_PM_profile_validation"].iloc[0]
    print(f"Gaia PM validation status:       {pmrow.independence_status}; N={int(pmrow.N)}")
    print("")
    print("SEND BACK:")
    print("  outputs\\stage03b_summary.txt")
    print("  outputs\\stage03b_potential_ledger.csv")
    print("  outputs\\stage03b_controlled_potential_ledger.csv")
    print("  outputs\\stage03b_differential_ledger.csv")
    print("  outputs\\stage03b_external_validation_ledger.csv")
    print("  outputs\\stage03b_gaia_profile_schema.txt")

if __name__=="__main__":
    main()
