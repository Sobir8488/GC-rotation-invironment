from __future__ import annotations
import io, math, re, zipfile
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"
RAW=ROOT/"data"/"raw"

ZIP=RAW/"vasiliev_baumgardt_2021_clusters.zip"
MASTER=OUT/"stage02c_master_with_los.csv"
POT=OUT/"stage03b_potential_ledger.csv"
CTRL=OUT/"stage03b_controlled_potential_ledger.csv"

def norm(s):
    return re.sub(r"[^A-Z0-9]+","",str(s).upper())

def read_numeric(txt):
    rows=[]
    for ln in txt.splitlines():
        s=ln.strip()
        if not s or s.startswith(("#","!","%",";")):
            continue
        toks=re.split(r"\s+",s)
        vals=[]
        ok=True
        for t in toks:
            try: vals.append(float(t.replace("D","E").replace("d","e")))
            except Exception:
                ok=False; break
        if ok and len(vals)==12:
            rows.append(vals)
    return np.asarray(rows,float) if rows else np.empty((0,12))

def resolve_profile_key(member, master_keys):
    stem=norm(Path(member).stem)
    # Prefer exact key, then longest key appearing in the profile stem.
    if stem in master_keys:
        return stem,"exact"
    hits=[k for k in master_keys if len(k)>=3 and (stem.startswith(k) or k in stem)]
    if not hits:
        return None,"unmatched"
    hits=sorted(hits,key=len,reverse=True)
    # Ambiguity is not acceptable unless the longest match is unique in length/string.
    best=hits[0]
    if len(hits)>1 and len(hits[1])==len(best) and hits[1]!=best:
        return None,"ambiguous"
    return best,"substring"

def main():
    master=pd.read_csv(MASTER)
    master["cluster_key_norm"]=master["cluster_key"].map(norm)
    master_keys=set(master["cluster_key_norm"])
    key_to_row={r.cluster_key_norm:r for _,r in master.iterrows()}

    with zipfile.ZipFile(ZIP) as z:
        names=[n for n in z.namelist() if not n.endswith("/")]
        readme_name=next((n for n in names if Path(n).name.lower()=="!readme.txt"),None)
        if not readme_name:
            raise RuntimeError("!readme.txt not found in Gaia archive.")
        readme=z.read(readme_name).decode("utf-8",errors="replace")
        low=readme.lower()

        # Hard safety gate: require the archive's own documentation to describe
        # exactly the two 5-percentile blocks in the expected order.
        required=[
            'folder "profiles"',
            "pm dispersion",
            "pm rotation",
            "2.3",
            "15.9",
            "50",
            "84.1",
            "97.7",
        ]
        missing=[x for x in required if x not in low]
        if missing:
            raise RuntimeError("Gaia README schema safety gate failed; missing phrases: "+repr(missing))

        # The archive README documents:
        # col 1 radius;
        # cols 2-6 PM-dispersion percentiles (2.3,15.9,50,84.1,97.7);
        # cols 7-11 PM-rotation percentiles (2.3,15.9,50,84.1,97.7);
        # col 12 an additional radial-PM quantity.
        # Therefore the median PM rotation is 1-based column 9 / zero-based index 8.
        rot_med_idx=8
        profs=[n for n in names if n.lower().startswith("profiles/") and n.lower().endswith(".txt")]
        amps=[]
        audits=[]
        for n in profs:
            mat=read_numeric(z.read(n).decode("utf-8",errors="replace"))
            key,method=resolve_profile_key(n,master_keys)
            if mat.shape[0]==0:
                audits.append(dict(member=n,status="no_12col_rows",match_method=method))
                continue
            if key is None:
                audits.append(dict(member=n,status="cluster_unmatched",match_method=method))
                continue
            row=key_to_row[key]
            dist=float(row.r_sun_kpc) if np.isfinite(row.r_sun_kpc) else np.nan
            medrot=mat[:,rot_med_idx]
            good=np.isfinite(medrot)
            if not np.any(good) or not np.isfinite(dist) or dist<=0:
                audits.append(dict(member=n,status="no_finite_rotation_or_distance",match_method=method))
                continue
            amp_masyr=float(np.nanmax(np.abs(medrot[good])))
            j=int(np.nanargmax(np.abs(medrot)))
            radius_deg=float(mat[j,0])
            amp_kms=amp_masyr*4.74047*dist
            amps.append(dict(
                cluster=row.cluster,cluster_key=row.cluster_key,profile_member=n,
                match_method=method,n_profile_points=int(mat.shape[0]),
                pm_rotation_median_col_1based=9,
                Arot_PM_masyr=amp_masyr,Arot_PM_kms=amp_kms,
                radius_at_absmax_deg=radius_deg,r_sun_kpc=dist
            ))
            audits.append(dict(member=n,status="used",match_method=method,cluster=row.cluster))

    amp=pd.DataFrame(amps)
    amp.to_csv(OUT/"stage03b_gaia_pm_amplitudes_v2.csv",index=False)
    pd.DataFrame(audits).to_csv(OUT/"stage03b_gaia_profile_match_audit_v2.csv",index=False)

    # Independent PM-channel validation on overlap with rebuilt primary LOS sample.
    los=master.dropna(subset=["primary_a_rot_los_kms"]).copy()
    ov=los.merge(amp[["cluster_key","Arot_PM_kms"]],on="cluster_key",how="inner")
    if len(ov)>=3:
        rho,p=spearmanr(ov["primary_a_rot_los_kms"],ov["Arot_PM_kms"])
    else:
        rho=p=np.nan

    # Preserve the previous non-independent consistency row.
    old=pd.read_csv(OUT/"stage03b_external_validation_ledger.csv")
    cat=old.loc[old.layer=="catalogue_literature_consistency"].copy()
    pmrow=pd.DataFrame([{
        "layer":"Gaia_EDR3_PM_profile_validation",
        "independence_status":"independent_PM_channel",
        "N":len(ov),"rho_s":rho,"p":p,"q_FDR":p,
        "definition":"Maximum absolute median tangential-PM rotation profile from the archive-documented columns, converted to km/s, versus rebuilt LOS A_rot"
    }])
    ext=pd.concat([cat,pmrow],ignore_index=True)
    ext.to_csv(OUT/"stage03b_external_validation_ledger_v2.csv",index=False)
    ov.to_csv(OUT/"stage03b_external_validation_overlap_v2.csv",index=False)

    colmap=[
        "JAA STAGE 03B PATCH01 - GAIA PROFILE COLUMN MAP",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),
        "",
        "Schema accepted only because the archive !readme.txt explicitly documents",
        "the profile percentile blocks for PM dispersion and PM rotation.",
        "",
        "1-based column map used:",
        "  1      radial coordinate",
        "  2--6   PM-dispersion percentiles: 2.3, 15.9, 50, 84.1, 97.7",
        "  7--11  PM-rotation percentiles:   2.3, 15.9, 50, 84.1, 97.7",
        "  12     additional radial-PM quantity (not used here)",
        "",
        "External validation uses column 9 (median PM rotation) and defines",
        "Arot_PM = max_R |median(mu_rot(R))|.",
        "Conversion: v_t [km/s] = 4.74047 * D[kpc] * mu[mas/yr].",
        "",
        f"Profile files scanned: {len([a for a in audits])}",
        f"Usable/matched PM profiles: {len(amp)}",
        f"Overlap with rebuilt LOS primary sample: {len(ov)}",
        f"Spearman rho_S: {rho}",
        f"Two-sided p: {p}",
    ]
    (OUT/"stage03b_gaia_profile_column_map.txt").write_text("\n".join(colmap)+"\n",encoding="utf-8")

    # Audit the existing 0.8/1.0/1.2 potential family.
    pot=pd.read_csv(POT)
    ctrl=pd.read_csv(CTRL)
    lines=[
        "JAA STAGE 03B PATCH01 - POTENTIAL SENSITIVITY AUDIT",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),
        "",
        "IMPORTANT STATISTICAL POINT:",
        "The current light/fiducial/heavy models differ only by a common",
        "multiplicative mass normalization (0.8, 1.0, 1.2) with all scale",
        "lengths fixed. Under this homologous scaling, the rank ordering of",
        "lambda_max, Tphi, and fJ is unchanged across clusters. Therefore",
        "Spearman rho and p are expected to be exactly invariant across the",
        "three variants. Their identical coefficients are algebraic, not",
        "independent evidence of potential-model robustness.",
        "",
        "MANUSCRIPT POLICY:",
        "- Keep the fiducial model as the explicit physical reparameterization.",
        "- Retain light/heavy only as dimensional-amplitude sensitivity variants.",
        "- Do NOT claim 'stable Spearman signs across light/fiducial/heavy' as a",
        "  robustness result from these homologous variants.",
        "- If rank-robustness across Galactic potentials is desired, use genuinely",
        "  non-homologous models with different component ratios/scale lengths.",
        "",
        "Existing raw ledger equality check:"
    ]
    metrics=["rho_s","p","q_FDR"]
    for relation,sub in pot.groupby(["x","y"]):
        vals={m:sub[m].tolist() for m in metrics if m in sub}
        lines.append(f"  {relation}: {vals}")
    lines += ["","Existing controlled ledger equality check:"]
    for relation,sub in ctrl.groupby(["x","y"]):
        vals={m:sub[m].tolist() for m in ["rho_partial_s","p","q_FDR"] if m in sub}
        lines.append(f"  {relation}: {vals}")
    (OUT/"stage03b_potential_sensitivity_audit.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    summary=[
        "JAA_REPRO_REBUILD STAGE 03B PATCH01 SUMMARY",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),"",
        "GAIA EDR3 INDEPENDENT PM VALIDATION",
        f"Usable matched PM profile amplitudes: {len(amp)}",
        f"Overlap with rebuilt LOS primary sample: {len(ov)}",
        f"rho_S = {rho}",
        f"p = {p}",
        "",
        "POTENTIAL ROBUSTNESS AUDIT",
        "The current 0.8/1.0/1.2 common-mass variants are homologous.",
        "Identical Spearman results across them are mathematically expected.",
        "Use fiducial model for inferential reporting; describe light/heavy only",
        "as dimensional-amplitude sensitivity unless a non-homologous family is added.",
        "",
        "NEXT DECISION:",
        "If the Gaia PM overlap is adequate, Stage 04 can freeze final result tables,",
        "regenerate all figures, revise the manuscript, and build the repository package."
    ]
    (OUT/"stage03b_patch01_summary.txt").write_text("\n".join(summary)+"\n",encoding="utf-8")

    print("JAA STAGE 03B PATCH01 SUMMARY")
    print(f"Usable Gaia PM profiles:          {len(amp)}")
    print(f"PM/LOS overlap:                   {len(ov)}")
    if np.isfinite(rho):
        print(f"Independent PM validation:        rho={rho:.4f}, p={p:.3g}")
    else:
        print("Independent PM validation:        unavailable")
    print("Potential scaling audit:          HOMOLOGOUS rank-invariant family")
    print("")
    print("SEND BACK:")
    print("  outputs\\stage03b_external_validation_ledger_v2.csv")
    print("  outputs\\stage03b_gaia_pm_amplitudes_v2.csv")
    print("  outputs\\stage03b_gaia_profile_column_map.txt")
    print("  outputs\\stage03b_potential_sensitivity_audit.txt")
    print("  outputs\\stage03b_patch01_summary.txt")

if __name__=="__main__":
    main()
