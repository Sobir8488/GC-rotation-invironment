from __future__ import annotations

import argparse
import math
import re
import sys
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yaml
from scipy.optimize import minimize
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

STRUCT_NAMES = [
    "cluster","ra_deg","dec_deg","r_sun_kpc","dr_sun_kpc","r_gc_kpc","dr_gc_kpc",
    "n_rv_catalog","n_pm_catalog","mass_msun","d_mass_msun","v_mag","d_v_mag",
    "ml_v","d_ml_v","rc_pc","rh_l_pc","rh_m_pc","rt_pc","log_rho_c",
    "log_rho_h_m","sig_c_kms","sig_h_m_kms","log_trh_yr","log_mini_msun",
    "t_diss_gyr","m_low_msun","m_high_msun","mf_slope","d_mf_slope",
    "sig0_kms","vesc_kms","eta_c","eta_h","a_rot_catalog_kms",
    "d_a_rot_catalog_kms","p_rot_percent"
]

ORBIT_NAMES = [
    "cluster","ra_deg_orbit","dec_deg_orbit","l_deg","b_deg","r_sun_kpc_orbit",
    "dr_sun_kpc_orbit","r_gc_kpc_orbit","mean_rv_kms","e_mean_rv_kms",
    "pmra_masyr","e_pmra_masyr","pmdec_masyr","e_pmdec_masyr","pm_corr",
    "x_kpc","e_x_kpc","y_kpc","e_y_kpc","z_kpc","e_z_kpc",
    "u_kms","e_u_kms","v_kms","e_v_kms","w_kms","e_w_kms",
    "r_peri_kpc","e_r_peri_kpc","r_apo_kpc","e_r_apo_kpc"
]

def norm_name(x: str) -> str:
    s = str(x).strip().upper()
    replacements = {
        "2MASSGC01":"2MSGC01",
        "2MASSGC02":"2MSGC02",
        "GLIMPSE2":"GLI2",
        "SAGITTARIUSII":"SGRII",
    }
    s = re.sub(r"[^A-Z0-9]+", "", s)
    return replacements.get(s, s)

def read_ws_table(path: Path, names: list[str]) -> pd.DataFrame:
    rows=[]
    with path.open("r",encoding="utf-8",errors="replace") as f:
        for ln in f:
            if not ln.strip() or ln.lstrip().startswith("#"):
                continue
            toks=re.split(r"\s+",ln.strip())
            if len(toks) > len(names):
                toks=toks[:len(names)]
            if len(toks) < len(names):
                toks=toks + [None]*(len(names)-len(toks))
            rows.append(toks)
    df=pd.DataFrame(rows,columns=names)
    if df.empty:
        raise RuntimeError(f"No data rows parsed from {path}")
    for c in names[1:]:
        df[c]=pd.to_numeric(df[c],errors="coerce")
    df["cluster"]=df["cluster"].astype(str)
    df["cluster_key"]=df["cluster"].map(norm_name)
    return df

def circular_max_gap(theta: np.ndarray) -> float:
    if len(theta)<2:
        return 360.0
    d=np.sort(np.mod(np.degrees(theta),360.0))
    gaps=np.diff(np.r_[d,d[0]+360.0])
    return float(np.max(gaps))

def angular_coverage(theta: np.ndarray, nbins: int) -> tuple[int,float]:
    if len(theta)==0:
        return 0,360.0
    b=np.floor((np.mod(theta,2*np.pi))/(2*np.pi)*nbins).astype(int)
    b=np.clip(b,0,nbins-1)
    return int(len(np.unique(b))), circular_max_gap(theta)

def tangent_theta(ra,dec,ra0,dec0):
    dra=((np.asarray(ra)-ra0+180.0)%360.0)-180.0
    x=dra*np.cos(np.deg2rad(dec0))
    y=np.asarray(dec)-dec0
    # east of north; amplitude invariant to zero-point convention
    return np.arctan2(x,y), np.hypot(x,y)*3600.0

def robust_mad(x):
    x=np.asarray(x,float)
    med=np.nanmedian(x)
    mad=np.nanmedian(np.abs(x-med))
    return med,1.4826*mad

def parse_rv_file(path: Path) -> pd.DataFrame:
    rows=[]
    with path.open("r",encoding="utf-8",errors="replace") as f:
        for ln in f:
            if not ln.strip():
                continue
            toks=re.split(r"\s+",ln.strip())
            if len(toks)<11:
                continue
            # Data rows: cluster, RA, DEC, DCEN, RV, E_RV, NRV, MJD,
            # P_Single, PMEM_RV, PMEM_PM, followed by photometric/aux columns.
            try:
                ra=float(toks[1]); dec=float(toks[2]); dcen=float(toks[3])
                rv=float(toks[4]); erv=float(toks[5])
            except Exception:
                continue
            def fnum(i):
                if i>=len(toks): return np.nan
                try: return float(toks[i])
                except Exception: return np.nan
            rows.append({
                "cluster_token":toks[0],
                "ra_deg":ra,
                "dec_deg":dec,
                "dcen_arcsec_reported":dcen,
                "rv_kms":rv,
                "erv_kms":erv,
                "nrv":fnum(6),
                "mjd":fnum(7),
                "p_single":fnum(8),
                "pmem_rv":fnum(9),
                "pmem_pm":fnum(10),
                "g_mag":fnum(11),
                "bp_rp_mag":fnum(12),
                "token_count":len(toks),
            })
    return pd.DataFrame(rows)

def resolve_cluster(path: Path, stars: pd.DataFrame, master: pd.DataFrame):
    candidates=[]
    stem_key=norm_name(path.stem)
    candidates.append(("filename",stem_key))
    if not stars.empty:
        mode=stars["cluster_token"].astype(str).mode()
        if len(mode):
            candidates.append(("row_token",norm_name(mode.iloc[0])))
    keys=set(master["cluster_key"])
    for method,key in candidates:
        if key in keys:
            row=master.loc[master.cluster_key==key].iloc[0]
            return row["cluster"],key,method,0.0
    # coordinate fallback
    if not stars.empty:
        ra=float(np.nanmedian(stars.ra_deg)); dec=float(np.nanmedian(stars.dec_deg))
        m=master.dropna(subset=["ra_deg","dec_deg"]).copy()
        dra=((m.ra_deg.to_numpy()-ra+180)%360)-180
        dx=dra*np.cos(np.deg2rad(dec))
        dy=m.dec_deg.to_numpy()-dec
        sep=np.hypot(dx,dy)*60.0
        if len(sep):
            j=int(np.argmin(sep))
            if sep[j] <= 10.0:
                row=m.iloc[j]
                return row["cluster"],row["cluster_key"],"coordinate",float(sep[j])
    return path.stem,stem_key,"unmatched",np.nan

def probability_pass(values: pd.Series, threshold: float, missing_policy: str):
    v=pd.to_numeric(values,errors="coerce")
    if missing_policy=="keep":
        return v.isna() | (v>=threshold)
    return v.notna() & (v>=threshold)

def select_stars(df, cfg, threshold):
    q=cfg["velocity_quality"]; mem=cfg["membership"]
    mask=np.isfinite(df.ra_deg)&np.isfinite(df.dec_deg)&np.isfinite(df.rv_kms)&np.isfinite(df.erv_kms)
    mask &= (df.erv_kms > float(q["min_erv_kms"])) & (df.erv_kms <= float(q["max_erv_kms"]))
    mask &= probability_pass(df.pmem_rv,threshold,mem["missing_probability_policy"])
    mask &= probability_pass(df.pmem_pm,threshold,mem["missing_probability_policy"])
    mask &= probability_pass(df.p_single,float(mem["single_star_threshold"]),mem["missing_probability_policy"])
    d=df.loc[mask].copy()
    if len(d)>=5:
        med,scale=robust_mad(d.rv_kms)
        if not np.isfinite(scale) or scale<=0:
            scale=float(np.nanstd(d.rv_kms))
        if np.isfinite(scale) and scale>0:
            d=d.loc[np.abs(d.rv_kms-med) <= float(q["robust_clip_sigma"])*scale].copy()
    return d

def nll(par,v,e,theta):
    v0,a,b,logsig=par
    sig=np.exp(logsig)
    var=e*e+sig*sig
    mu=v0+a*np.sin(theta)+b*np.cos(theta)
    return 0.5*np.sum(np.log(2*np.pi*var)+(v-mu)**2/var)

def fit_rotation(d,ra0,dec0,cfg):
    if len(d)<4:
        return {"fit_ok":False,"fit_message":"too_few_rows"}
    theta,r_arcsec=tangent_theta(d.ra_deg.to_numpy(),d.dec_deg.to_numpy(),ra0,dec0)
    v=d.rv_kms.to_numpy(float); e=d.erv_kms.to_numpy(float)
    occ,gap=angular_coverage(theta,int(cfg["rotation_fit"]["angular_bins"]))
    X=np.c_[np.ones(len(v)),np.sin(theta),np.cos(theta)]
    try:
        beta=np.linalg.lstsq(X,v,rcond=None)[0]
    except Exception:
        beta=np.array([np.nanmedian(v),0.0,0.0])
    _,rs=robust_mad(v)
    if not np.isfinite(rs) or rs<=0: rs=max(float(np.nanstd(v)),0.5)
    x0=np.r_[beta,np.log(max(rs,0.05))]
    vmax=max(100.0,5.0*max(rs,1.0))
    bounds=[(np.nanmin(v)-vmax,np.nanmax(v)+vmax),(-vmax,vmax),(-vmax,vmax),(np.log(0.01),np.log(vmax))]
    res=minimize(nll,x0,args=(v,e,theta),method="L-BFGS-B",bounds=bounds,
                 options={"maxiter":int(cfg["rotation_fit"]["optimizer_maxiter"])})
    v0,a,b,logsig=res.x
    amp=float(np.hypot(a,b))
    phase=float(np.degrees(np.arctan2(b,a))%360.0)
    # information-based covariance approximation
    amp_err=np.nan
    try:
        Hinv=np.asarray(res.hess_inv.todense())
        cab=Hinv[1:3,1:3]
        if amp>0 and np.all(np.isfinite(cab)):
            g=np.array([a/amp,b/amp])
            va=float(g@cab@g)
            if va>=0: amp_err=float(np.sqrt(va))
    except Exception:
        pass
    return {
        "fit_ok":bool(res.success and np.isfinite(amp)),
        "fit_message":str(res.message),
        "n_fit":int(len(d)),
        "v0_kms":float(v0),"a_sin_kms":float(a),"b_cos_kms":float(b),
        "a_rot_los_kms":amp,"a_rot_los_err_approx_kms":amp_err,
        "phi_rot_deg":phase,"sigma_int_kms":float(np.exp(logsig)),
        "nll":float(res.fun),"angular_bins_occupied":occ,"max_angular_gap_deg":gap,
        "r_p10_arcsec":float(np.nanpercentile(r_arcsec,10)),
        "r_p50_arcsec":float(np.nanpercentile(r_arcsec,50)),
        "r_p90_arcsec":float(np.nanpercentile(r_arcsec,90)),
    }

def primary_quality(fit,cfg):
    if not fit.get("fit_ok",False): return False
    r=cfg["rotation_fit"]
    return (
        fit["n_fit"] >= int(r["min_stars_primary"]) and
        fit["angular_bins_occupied"] >= int(r["min_occupied_angular_bins"]) and
        fit["max_angular_gap_deg"] <= float(r["max_angular_gap_deg"])
    )

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--config",default="config/stage02b_analysis.yaml")
    args=ap.parse_args()
    cfg=yaml.safe_load((ROOT/args.config).read_text(encoding="utf-8"))

    structural=read_ws_table(RAW/"baumgardt_structural_combined.txt",STRUCT_NAMES)
    orbit=read_ws_table(RAW/"baumgardt_orbits_combined.txt",ORBIT_NAMES)

    # one-to-one merge on canonicalized cluster names
    dup_s=structural.cluster_key.duplicated(keep=False)
    dup_o=orbit.cluster_key.duplicated(keep=False)
    if dup_s.any():
        raise RuntimeError("Duplicate structural cluster keys: "+repr(structural.loc[dup_s,"cluster"].tolist()))
    if dup_o.any():
        raise RuntimeError("Duplicate orbit cluster keys: "+repr(orbit.loc[dup_o,"cluster"].tolist()))
    orbit2=orbit.drop(columns=["cluster"]).rename(columns={"cluster_key":"cluster_key"})
    master=structural.merge(orbit2,on="cluster_key",how="outer",indicator="merge_source")
    master.to_csv(OUT/"stage02b_master_catalogue.csv",index=False)

    rvdir=RAW/"rv_by_cluster"
    rvfiles=sorted(rvdir.glob("*.txt"))
    audit=[]
    fits=[]
    strict_thr=float(cfg["membership"]["strict_sensitivity_threshold"])
    primary_thr=float(cfg["membership"]["primary_threshold"])

    for i,path in enumerate(rvfiles,1):
        stars=parse_rv_file(path)
        cname,ckey,method,sep=resolve_cluster(path,stars,master)
        mrow=master.loc[master.cluster_key==ckey]
        if len(mrow)==1 and np.isfinite(mrow.iloc[0].get("ra_deg",np.nan)):
            ra0=float(mrow.iloc[0]["ra_deg"]); dec0=float(mrow.iloc[0]["dec_deg"])
        elif len(stars):
            ra0=float(np.nanmedian(stars.ra_deg)); dec0=float(np.nanmedian(stars.dec_deg))
        else:
            ra0=dec0=np.nan

        primary=select_stars(stars,cfg,primary_thr) if len(stars) else stars
        strict=select_stars(stars,cfg,strict_thr) if len(stars) else stars

        fp=fit_rotation(primary,ra0,dec0,cfg) if len(primary) else {"fit_ok":False,"fit_message":"no_selected_rows"}
        fs=fit_rotation(strict,ra0,dec0,cfg) if len(strict) else {"fit_ok":False,"fit_message":"no_selected_rows"}
        qp=primary_quality(fp,cfg)

        row={
            "cluster":cname,"cluster_key":ckey,"rv_file":path.name,
            "cluster_match_method":method,"coord_match_sep_arcmin":sep,
            "n_rows_parsed":int(len(stars)),"n_primary_selected":int(len(primary)),
            "n_strict_selected":int(len(strict)),
            "primary_quality":bool(qp),
        }
        row.update({f"primary_{k}":v for k,v in fp.items()})
        row.update({f"strict_{k}":v for k,v in fs.items()})
        fits.append(row)

        widths=stars.token_count.value_counts().to_dict() if len(stars) else {}
        audit.append({
            "rv_file":path.name,"cluster":cname,"match_method":method,
            "n_rows_parsed":int(len(stars)),"n_primary_selected":int(len(primary)),
            "token_widths":repr(widths),
            "median_reported_dcen_arcsec":float(np.nanmedian(stars.dcen_arcsec_reported)) if len(stars) else np.nan,
        })
        if i%20==0 or i==len(rvfiles):
            print(f"RV fits processed: {i}/{len(rvfiles)}")

    fitdf=pd.DataFrame(fits)
    fitdf.to_csv(OUT/"stage02b_los_rotation_catalog.csv",index=False)
    pd.DataFrame(audit).to_csv(OUT/"stage02b_rv_parse_audit.csv",index=False)

    # Attach primary LOS result to master for the provisional direct-pericentre check.
    use=fitdf.loc[fitdf.primary_quality].copy()
    mm=master.merge(use[["cluster_key","primary_n_fit","primary_a_rot_los_kms",
                         "primary_a_rot_los_err_approx_kms","primary_sigma_int_kms",
                         "primary_angular_bins_occupied","primary_max_angular_gap_deg"]],
                    on="cluster_key",how="left")
    mm.to_csv(OUT/"stage02b_master_with_los.csv",index=False)

    pair=mm.dropna(subset=["primary_a_rot_los_kms","r_peri_kpc"]).copy()
    if len(pair)>=3:
        rho,p=spearmanr(pair["primary_a_rot_los_kms"],pair["r_peri_kpc"])
    else:
        rho=p=np.nan
    check=pd.DataFrame([{
        "status":"PROVISIONAL_RAW_CHECK_NOT_FDR_ADJUSTED",
        "response":"rebuilt_Arot_LOS_primary",
        "descriptor":"R_peri",
        "N":len(pair),"rho_s":rho,"p_two_sided":p,
        "q_FDR":np.nan,
        "note":"Do not promote to manuscript claim until the complete pre-specified family is rebuilt in Stage 03."
    }])
    check.to_csv(OUT/"stage02b_direct_pericentre_check.csv",index=False)

    unmatched=int((fitdf.cluster_match_method=="unmatched").sum())
    qn=int(fitdf.primary_quality.sum())
    parsed=int(fitdf.n_rows_parsed.sum())
    sel=int(fitdf.n_primary_selected.sum())
    text=[
        "JAA_REPRO_REBUILD STAGE 02B SUMMARY",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),
        "",
        f"Structural rows: {len(structural)}",
        f"Orbit rows: {len(orbit)}",
        f"Merged master rows: {len(master)}",
        f"RV files processed: {len(rvfiles)}",
        f"RV star rows parsed: {parsed}",
        f"Primary selected star rows: {sel}",
        f"Unmatched RV cluster files: {unmatched}",
        f"Primary-quality LOS rotation clusters: {qn}",
        "",
        "PRIMARY STAR SELECTION (pre-specified):",
        f"  PMEM_RV >= {primary_thr} when available",
        f"  PMEM_PM >= {primary_thr} when available",
        f"  P_Single >= {cfg['membership']['single_star_threshold']} when available",
        f"  0 < E_RV <= {cfg['velocity_quality']['max_erv_kms']} km/s",
        f"  robust RV clipping: {cfg['velocity_quality']['robust_clip_sigma']} MAD-sigma",
        "",
        "PRIMARY CLUSTER QUALITY:",
        f"  N_stars >= {cfg['rotation_fit']['min_stars_primary']}",
        f"  occupied angular bins >= {cfg['rotation_fit']['min_occupied_angular_bins']} / {cfg['rotation_fit']['angular_bins']}",
        f"  maximum angular gap <= {cfg['rotation_fit']['max_angular_gap_deg']} deg",
        "",
        "PROVISIONAL DIRECT-PERICENTRE CHECK (not yet FDR-adjusted):",
        f"  N = {len(pair)}",
        f"  rho_S = {rho:.6g}" if np.isfinite(rho) else "  rho_S = NaN",
        f"  p = {p:.6g}" if np.isfinite(p) else "  p = NaN",
        "",
        "IMPORTANT:",
        "  This rebuild is not calibrated toward the historical manuscript values.",
        "  Approximate amplitude errors are optimizer-Hessian diagnostics only.",
        "  Bootstrap/null calibration and the complete FDR/control ledger are Stage 03 tasks.",
    ]
    (OUT/"stage02b_summary.txt").write_text("\n".join(text)+"\n",encoding="utf-8")

    print("")
    print("JAA_REPRO_REBUILD STAGE 02B SUMMARY")
    print(f"Structural rows:                    {len(structural)}")
    print(f"Orbit rows:                         {len(orbit)}")
    print(f"Merged master rows:                 {len(master)}")
    print(f"RV files processed:                 {len(rvfiles)}")
    print(f"RV star rows parsed:                {parsed}")
    print(f"Primary selected star rows:         {sel}")
    print(f"Unmatched RV files:                 {unmatched}")
    print(f"Primary-quality LOS clusters:       {qn}")
    print(f"Provisional Arot_LOS vs R_peri:     N={len(pair)}, rho={rho:.4f}, p={p:.3g}" if np.isfinite(rho) else "Provisional check unavailable")
    print("")
    print("SEND BACK:")
    print("  outputs\\stage02b_summary.txt")
    print("  outputs\\stage02b_direct_pericentre_check.csv")
    print("If unmatched RV files > 0, also send stage02b_rv_parse_audit.csv.")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
