from __future__ import annotations
import argparse, math, re
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yaml
from scipy.optimize import minimize
from scipy.stats import spearmanr

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/"data"/"raw"
OUT=ROOT/"outputs"
OUT.mkdir(parents=True,exist_ok=True)

def norm_name(x):
    return re.sub(r"[^A-Z0-9]+","",str(x).strip().upper())

def fnum(tok):
    try:
        return float(str(tok).replace("D","E").replace("d","e"))
    except Exception:
        return np.nan

def sep_arcsec(ra,dec,ra0,dec0):
    dra=((ra-ra0+180.0)%360.0)-180.0
    x=dra*np.cos(np.deg2rad(dec0))
    y=dec-dec0
    return float(np.hypot(x,y)*3600.0)

def sexa_to_deg(h,m,s,d,dm,ds):
    if not (0<=h<=24 and 0<=m<60 and 0<=s<60): return None
    if not (-90<=d<=90 and 0<=abs(dm)<60 and 0<=abs(ds)<60): return None
    ra=15.0*(h+m/60.0+s/3600.0)
    sign=-1.0 if d<0 or (d==0 and str(d).startswith("-")) else 1.0
    dec=sign*(abs(d)+abs(dm)/60.0+abs(ds)/3600.0)
    if not (0<=ra<=360 and -90<=dec<=90): return None
    return ra,dec

def candidate_from(toks,start,mode,ra0,dec0):
    try:
        if mode=="decimal":
            ra=fnum(toks[start]); dec=fnum(toks[start+1]); j=start+2
            if not (np.isfinite(ra) and np.isfinite(dec) and 0<=ra<=360 and -90<=dec<=90):
                return None
        else:
            vals=[fnum(toks[start+k]) for k in range(6)]
            if not all(np.isfinite(vals)): return None
            sd=sexa_to_deg(*vals)
            if sd is None: return None
            ra,dec=sd; j=start+6

        # Core fields following coordinates.
        dcen=fnum(toks[j]); rv=fnum(toks[j+1]); erv=fnum(toks[j+2])
        nrv=fnum(toks[j+3]) if j+3<len(toks) else np.nan
        mjd=fnum(toks[j+4]) if j+4<len(toks) else np.nan
        ps=fnum(toks[j+5]) if j+5<len(toks) else np.nan
        prv=fnum(toks[j+6]) if j+6<len(toks) else np.nan
        ppm=fnum(toks[j+7]) if j+7<len(toks) else np.nan
        g=fnum(toks[j+8]) if j+8<len(toks) else np.nan
        bprp=fnum(toks[j+9]) if j+9<len(toks) else np.nan

        if not (np.isfinite(dcen) and dcen>=0 and np.isfinite(rv) and np.isfinite(erv) and erv>=0):
            return None
        calc=sep_arcsec(ra,dec,ra0,dec0)
        abs_err=abs(calc-dcen)
        rel_err=abs_err/max(dcen,1.0)

        # Score primarily by agreement with the file's DCEN column.
        score=np.log1p(abs_err) + 0.5*np.log1p(rel_err)
        if abs(rv)>1000: score+=4
        if erv>100: score+=3
        return {
            "ra_deg":ra,"dec_deg":dec,"dcen_arcsec_reported":dcen,
            "dcen_arcsec_computed":calc,"dcen_abs_err_arcsec":abs_err,
            "dcen_rel_err":rel_err,"rv_kms":rv,"erv_kms":erv,"nrv":nrv,
            "mjd":mjd,"p_single":ps,"pmem_rv":prv,"pmem_pm":ppm,
            "g_mag":g,"bp_rp_mag":bprp,
            "_score":score,"_mode":mode,"_start":start,"_token_count":len(toks)
        }
    except Exception:
        return None

def parse_file(path,ra0,dec0):
    parsed=[]
    mode_counts={}
    with path.open("r",encoding="utf-8",errors="replace") as f:
        for ln in f:
            if not ln.strip(): continue
            toks=re.split(r"\s+",ln.strip())
            cands=[]
            # Allow one- or two-token cluster labels and mild format variation.
            for start in (1,2,3):
                if start+2 < len(toks):
                    c=candidate_from(toks,start,"decimal",ra0,dec0)
                    if c: cands.append(c)
                if start+7 < len(toks):
                    c=candidate_from(toks,start,"sexagesimal",ra0,dec0)
                    if c: cands.append(c)
            if not cands:
                continue
            best=min(cands,key=lambda x:x["_score"])
            parsed.append(best)
            k=f"{best['_mode']}_start{best['_start']}"
            mode_counts[k]=mode_counts.get(k,0)+1
    df=pd.DataFrame(parsed)
    return df,mode_counts

def norm_prob(s):
    x=pd.to_numeric(s,errors="coerce").astype(float)
    y=x.copy()
    percent=(y>1.0)&(y<=100.0)
    y.loc[percent]=y.loc[percent]/100.0
    y.loc[(y<0)|(y>1)]=np.nan
    return y

def pass_prob(s,thr,missing_policy):
    x=norm_prob(s)
    return (x.isna() | (x>=thr)) if missing_policy=="keep" else (x.notna()&(x>=thr))

def robust_select(df,cfg,strict=False):
    if df.empty: return df.copy()
    q=cfg["velocity_quality"]; m=cfg["membership"]
    thr=float(m["strict_threshold"] if strict else m["primary_threshold"])
    mask=np.isfinite(df.rv_kms)&np.isfinite(df.erv_kms)&np.isfinite(df.ra_deg)&np.isfinite(df.dec_deg)
    mask &= (df.erv_kms>float(q["min_erv_kms"]))&(df.erv_kms<=float(q["max_erv_kms"]))
    mask &= pass_prob(df.pmem_rv,thr,m["missing_probability_policy"])
    mask &= pass_prob(df.pmem_pm,thr,m["missing_probability_policy"])
    if strict:
        mask &= pass_prob(df.p_single,float(m["strict_single_star_threshold"]),m["missing_probability_policy"])
    d=df.loc[mask].copy()
    if len(d)>=5:
        med=np.nanmedian(d.rv_kms)
        mad=1.4826*np.nanmedian(np.abs(d.rv_kms-med))
        if not np.isfinite(mad) or mad<=0: mad=np.nanstd(d.rv_kms)
        if np.isfinite(mad) and mad>0:
            d=d.loc[np.abs(d.rv_kms-med)<=float(q["robust_clip_sigma"])*mad].copy()
    return d

def theta_radius(ra,dec,ra0,dec0):
    dra=((np.asarray(ra)-ra0+180)%360)-180
    x=dra*np.cos(np.deg2rad(dec0))
    y=np.asarray(dec)-dec0
    return np.arctan2(x,y),np.hypot(x,y)*3600

def coverage(theta,nb=12):
    if len(theta)==0:return 0,360.0
    deg=np.mod(np.degrees(theta),360.0)
    bins=np.floor(deg/360*nb).astype(int)
    occ=len(np.unique(np.clip(bins,0,nb-1)))
    s=np.sort(deg); gaps=np.diff(np.r_[s,s[0]+360])
    return int(occ),float(np.max(gaps))

def nll(par,v,e,t):
    v0,a,b,ls=par
    sig=np.exp(ls); var=e*e+sig*sig
    mu=v0+a*np.sin(t)+b*np.cos(t)
    return 0.5*np.sum(np.log(2*np.pi*var)+(v-mu)**2/var)

def fit_rot(d,ra0,dec0,cfg):
    if len(d)<4:return {"fit_ok":False,"fit_message":"too_few_rows","n_fit":len(d)}
    t,r=theta_radius(d.ra_deg,d.dec_deg,ra0,dec0)
    v=d.rv_kms.to_numpy(float); e=d.erv_kms.to_numpy(float)
    occ,gap=coverage(t,int(cfg["rotation_fit"]["angular_bins"]))
    X=np.c_[np.ones(len(v)),np.sin(t),np.cos(t)]
    beta=np.linalg.lstsq(X,v,rcond=None)[0]
    med=np.nanmedian(v); mad=1.4826*np.nanmedian(np.abs(v-med))
    if not np.isfinite(mad) or mad<=0: mad=max(np.nanstd(v),0.5)
    vmax=max(50.0,5*mad)
    x0=np.r_[beta,np.log(max(mad,0.05))]
    bounds=[(np.nanmin(v)-vmax,np.nanmax(v)+vmax),(-vmax,vmax),(-vmax,vmax),(np.log(0.01),np.log(vmax))]
    res=minimize(nll,x0,args=(v,e,t),method="L-BFGS-B",bounds=bounds,
                 options={"maxiter":int(cfg["rotation_fit"]["optimizer_maxiter"])})
    v0,a,b,ls=res.x
    amp=float(np.hypot(a,b))
    return {
        "fit_ok":bool(res.success and np.isfinite(amp)),"fit_message":str(res.message),
        "n_fit":int(len(d)),"v0_kms":float(v0),"a_sin_kms":float(a),"b_cos_kms":float(b),
        "a_rot_los_kms":amp,"phi_rot_deg":float(np.degrees(np.arctan2(b,a))%360),
        "sigma_int_kms":float(np.exp(ls)),"angular_bins_occupied":occ,
        "max_angular_gap_deg":gap,"r_p10_arcsec":float(np.nanpercentile(r,10)),
        "r_p50_arcsec":float(np.nanpercentile(r,50)),"r_p90_arcsec":float(np.nanpercentile(r,90))
    }

def quality(f,cfg):
    r=cfg["rotation_fit"]
    return bool(f.get("fit_ok",False) and f.get("n_fit",0)>=int(r["min_stars_primary"])
                and f.get("angular_bins_occupied",0)>=int(r["min_occupied_angular_bins"])
                and f.get("max_angular_gap_deg",360)<=float(r["max_angular_gap_deg"]))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--config"); args=ap.parse_args()
    cfg=yaml.safe_load((ROOT/args.config).read_text(encoding="utf-8"))
    master=pd.read_csv(OUT/"stage02b_master_catalogue.csv")
    master["cluster_key"]=master["cluster_key"].astype(str)
    rvdir=RAW/"rv_by_cluster"
    audit=[]; rows=[]
    for i,path in enumerate(sorted(rvdir.glob("*.txt")),1):
        key=norm_name(path.stem)
        # Filename and master names are already known to match from Stage 02B.
        m=master.loc[master.cluster_key.astype(str).map(norm_name)==key]
        if len(m)!=1:
            # coordinate/name fallback via the old Stage 02B catalog if needed
            old=pd.read_csv(OUT/"stage02b_los_rotation_catalog.csv")
            hit=old.loc[old.rv_file==path.name]
            if len(hit):
                key2=str(hit.iloc[0].cluster_key)
                m=master.loc[master.cluster_key.astype(str)==key2]
        if len(m)!=1:
            audit.append({"rv_file":path.name,"parser_status":"master_match_failed"})
            continue
        mr=m.iloc[0]; ra0=float(mr.ra_deg); dec0=float(mr.dec_deg)
        stars,modes=parse_file(path,ra0,dec0)
        if stars.empty:
            audit.append({"rv_file":path.name,"cluster":mr.cluster,"parser_status":"no_rows"})
            continue
        prim=robust_select(stars,cfg,strict=False)
        strict=robust_select(stars,cfg,strict=True)
        fp=fit_rot(prim,ra0,dec0,cfg); fs=fit_rot(strict,ra0,dec0,cfg)
        med_abs=float(np.nanmedian(stars.dcen_abs_err_arcsec))
        med_rel=float(np.nanmedian(stars.dcen_rel_err))
        dom=max(modes,key=modes.get) if modes else ""
        parser_ok=(med_rel<=float(cfg["parser_validation"]["max_median_dcen_relative_error"])
                   or med_abs<=float(cfg["parser_validation"]["max_median_dcen_absolute_error_arcsec"]))
        audit.append({
            "rv_file":path.name,"cluster":mr.cluster,"parser_status":"ok" if parser_ok else "dcen_mismatch",
            "n_parsed":len(stars),"dominant_mode":dom,"mode_counts":repr(modes),
            "median_dcen_abs_err_arcsec":med_abs,"median_dcen_rel_err":med_rel,
            "pmem_rv_finite":int(norm_prob(stars.pmem_rv).notna().sum()),
            "pmem_pm_finite":int(norm_prob(stars.pmem_pm).notna().sum()),
            "p_single_finite":int(norm_prob(stars.p_single).notna().sum()),
        })
        row={"cluster":mr.cluster,"cluster_key":mr.cluster_key,"rv_file":path.name,
             "parser_ok":parser_ok,"parser_mode":dom,"n_rows_parsed":len(stars),
             "n_primary_selected":len(prim),"n_strict_selected":len(strict),
             "primary_quality":quality(fp,cfg),"strict_quality":quality(fs,cfg)}
        row.update({"primary_"+k:v for k,v in fp.items()})
        row.update({"strict_"+k:v for k,v in fs.items()})
        rows.append(row)
        if i%20==0 or i==161: print(f"Repaired RV fits processed: {i}/161")

    a=pd.DataFrame(audit); f=pd.DataFrame(rows)
    a.to_csv(OUT/"stage02c_parser_audit.csv",index=False)
    f.to_csv(OUT/"stage02c_los_rotation_catalog.csv",index=False)

    use=f.loc[f.primary_quality & f.parser_ok].copy()
    mm=master.merge(use[["cluster_key","primary_n_fit","primary_a_rot_los_kms","primary_sigma_int_kms",
                         "primary_angular_bins_occupied","primary_max_angular_gap_deg"]],
                    on="cluster_key",how="left")
    mm.to_csv(OUT/"stage02c_master_with_los.csv",index=False)
    pair=mm.dropna(subset=["primary_a_rot_los_kms","r_peri_kpc"]).copy()
    if len(pair)>=3:
        rho,p=spearmanr(pair.primary_a_rot_los_kms,pair.r_peri_kpc)
    else: rho=p=np.nan
    pd.DataFrame([{"status":"PROVISIONAL_RAW_CHECK_NOT_FDR_ADJUSTED","N":len(pair),
                   "rho_s":rho,"p_two_sided":p,"q_FDR":np.nan,
                   "note":"Stage 03 required before manuscript use."}]).to_csv(
                       OUT/"stage02c_direct_pericentre_check.csv",index=False)

    parser_ok=int(a.parser_status.eq("ok").sum()) if len(a) else 0
    qn=int((f.primary_quality & f.parser_ok).sum()) if len(f) else 0
    strictn=int((f.strict_quality & f.parser_ok).sum()) if len(f) else 0
    parsed=int(f.n_rows_parsed.sum()) if len(f) else 0
    selected=int(f.n_primary_selected.sum()) if len(f) else 0
    modes=a.dominant_mode.value_counts().to_dict() if "dominant_mode" in a else {}
    amps=pd.to_numeric(use.get("primary_a_rot_los_kms"),errors="coerce") if len(use) else pd.Series(dtype=float)

    lines=[
        "JAA_REPRO_REBUILD STAGE 02C SUMMARY",
        "Generated UTC: "+datetime.now(timezone.utc).isoformat(),"",
        f"RV files successfully rebuilt: {len(f)}",
        f"Parser-validated files: {parser_ok}",
        f"Total repaired star rows parsed: {parsed}",
        f"Primary selected star rows: {selected}",
        f"Primary-quality + parser-valid clusters: {qn}",
        f"Strict-sensitivity + parser-valid clusters: {strictn}",
        f"Dominant parser modes: {modes}","",
        "PRIMARY POLICY:",
        "  coordinate parser selected from decimal or sexagesimal candidates by DCEN consistency;",
        "  PMEM_RV and PMEM_PM are membership gates when available;",
        "  P_Single is not a primary membership gate;",
        "  P_Single enters only the strict sensitivity layer.","",
    ]
    if len(amps):
        q=np.nanpercentile(amps,[10,50,90])
        lines += [f"Primary-quality Arot_LOS percentiles [10,50,90] km/s: {q[0]:.4g}, {q[1]:.4g}, {q[2]:.4g}",""]
    lines += [
        "PROVISIONAL DIRECT Arot_LOS vs R_peri (NOT FDR-adjusted):",
        f"  N = {len(pair)}",
        f"  rho_S = {rho:.6g}" if np.isfinite(rho) else "  rho_S = NaN",
        f"  p = {p:.6g}" if np.isfinite(p) else "  p = NaN","",
        "DECISION RULE:",
        "  If parser-valid/primary-quality sample is now population-sized and amplitudes are physically plausible,",
        "  proceed to Stage 03 bootstrap/null/FDR/control work.",
        "  Otherwise stop and inspect stage02c_parser_audit.csv before changing scientific thresholds."
    ]
    (OUT/"stage02c_summary.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print("")
    print("JAA_REPRO_REBUILD STAGE 02C SUMMARY")
    print(f"Parser-valid files:                    {parser_ok}/{len(f)}")
    print(f"Repaired star rows parsed:             {parsed}")
    print(f"Primary selected star rows:            {selected}")
    print(f"Primary-quality LOS clusters:          {qn}")
    print(f"Strict-sensitivity LOS clusters:       {strictn}")
    if np.isfinite(rho):
        print(f"Provisional Arot_LOS vs R_peri:        N={len(pair)}, rho={rho:.4f}, p={p:.3g}")
    else:
        print("Provisional Arot_LOS vs R_peri:        unavailable")
    print("")
    print("SEND BACK:")
    print("  outputs\\stage02c_summary.txt")
    print("  outputs\\stage02c_parser_audit.csv")
    print("  outputs\\stage02c_direct_pericentre_check.csv")

if __name__=="__main__":
    main()
