from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import statistics
import sys
import zipfile
from collections import Counter
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "outputs"
OUT.mkdir(parents=True, exist_ok=True)

REPORT = OUT / "stage02a_schema_report.txt"
RV_INV = OUT / "stage02a_rv_schema_inventory.csv"
GAIA_INV = OUT / "stage02a_gaia_zip_inventory.csv"
CAND = OUT / "stage02a_parse_candidates.json"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def read_text(path: Path, limit_bytes: int = 2_000_000) -> str:
    b = path.read_bytes()[:limit_bytes]
    for enc in ("utf-8", "latin-1", "cp1252"):
        try:
            return b.decode(enc)
        except Exception:
            pass
    return b.decode("utf-8", errors="replace")

def nonblank_lines(text: str):
    return [ln.rstrip("\r\n") for ln in text.splitlines() if ln.strip()]

def is_num(tok: str) -> bool:
    t = tok.strip().replace("D", "E").replace("d", "e")
    if t in {"", "-", "--", "...", "nan", "NaN", "NA", "N/A"}:
        return False
    try:
        float(t)
        return True
    except Exception:
        return False

def token_profile(lines):
    prof=[]
    for ln in lines:
        if ln.lstrip().startswith(("#","!","%",";")):
            continue
        toks=re.split(r"\s+", ln.strip())
        if not toks:
            continue
        nnum=sum(is_num(t) for t in toks)
        prof.append((len(toks), nnum, nnum/max(len(toks),1), ln))
    return prof

def summarize_text_table(path: Path):
    text=read_text(path)
    lines=nonblank_lines(text)
    prof=token_profile(lines[:300])
    widths=[x[0] for x in prof if x[2] >= 0.5]
    mode_width=Counter(widths).most_common(1)[0][0] if widths else None
    comment=sum(1 for x in lines[:300] if x.lstrip().startswith(("#","!","%",";")))
    samples=lines[:18]
    return {
        "path": str(path.relative_to(ROOT)),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "n_nonblank_first2MB": len(lines),
        "comment_lines_first300": comment,
        "numeric_mode_token_width": mode_width,
        "sample_lines": samples,
    }

def try_pandas_candidates(path: Path):
    out=[]
    # Candidate parsers for the live text tables.
    attempts = [
        ("whitespace", {"sep":r"\s+","engine":"python","comment":"#"}),
        ("tab", {"sep":"\t","engine":"python","comment":"#"}),
        ("comma", {"sep":",","engine":"python","comment":"#"}),
        ("semicolon", {"sep":";","engine":"python","comment":"#"}),
    ]
    for name,kw in attempts:
        try:
            df=pd.read_csv(path, nrows=300, **kw)
            out.append({
                "method":name,
                "rows":int(len(df)),
                "cols":int(len(df.columns)),
                "columns":[str(c) for c in list(df.columns)[:30]],
                "score": int(len(df) >= 20) + int(3 <= len(df.columns) <= 80),
            })
        except Exception as e:
            out.append({"method":name,"error":type(e).__name__+": "+str(e)[:180],"score":0})
    try:
        df=pd.read_fwf(path, nrows=300)
        out.append({
            "method":"fwf",
            "rows":int(len(df)),
            "cols":int(len(df.columns)),
            "columns":[str(c) for c in list(df.columns)[:30]],
            "score": int(len(df) >= 20) + int(3 <= len(df.columns) <= 80),
        })
    except Exception as e:
        out.append({"method":"fwf","error":type(e).__name__+": "+str(e)[:180],"score":0})
    return out

def rv_file_profile(path: Path):
    text=read_text(path, limit_bytes=500_000)
    lines=nonblank_lines(text)
    prof=token_profile(lines[:500])
    widths=[x[0] for x in prof if x[2] >= 0.5]
    mode_width=Counter(widths).most_common(1)[0][0] if widths else None
    numericish=sum(1 for x in prof if x[2] >= 0.5)
    return {
        "file":str(path.relative_to(ROOT)),
        "bytes":path.stat().st_size,
        "lines_first500k":len(lines),
        "numericish_lines_first500":numericish,
        "mode_numeric_token_width":mode_width if mode_width is not None else "",
        "first_nonblank": lines[0][:240] if lines else "",
        "second_nonblank": lines[1][:240] if len(lines)>1 else "",
    }

def inspect_gaia_zip(path: Path):
    inv=[]
    schema_notes=[]
    with zipfile.ZipFile(path) as z:
        names=[n for n in z.namelist() if not n.endswith("/")]
        ext_counts=Counter(Path(n).suffix.lower() or "<none>" for n in names)
        for n in names:
            info=z.getinfo(n)
            inv.append({
                "member":n,
                "extension":Path(n).suffix.lower(),
                "bytes_uncompressed":info.file_size,
                "bytes_compressed":info.compress_size,
            })
        # Inspect a few representative members by extension.
        reps=[]
        seen=set()
        for n in names:
            ext=Path(n).suffix.lower()
            if ext not in seen:
                reps.append(n); seen.add(ext)
            if len(reps)>=10: break
        for n in reps:
            ext=Path(n).suffix.lower()
            note={"member":n,"extension":ext}
            try:
                raw=z.read(n)
                if ext in {".csv",".txt",".dat",".ecsv"}:
                    txt=raw[:12000].decode("utf-8",errors="replace")
                    note["sample_lines"]=nonblank_lines(txt)[:12]
                elif ext in {".fits",".fit",".fts"}:
                    try:
                        from astropy.io import fits
                        with fits.open(io.BytesIO(raw), memmap=False) as hdul:
                            note["hdus"]=[]
                            for hdu in hdul[:5]:
                                item={"name":hdu.name,"class":hdu.__class__.__name__}
                                if getattr(hdu,"columns",None) is not None:
                                    item["columns"]=[str(x) for x in hdu.columns.names[:60]]
                                try:
                                    item["rows"]=len(hdu.data) if hdu.data is not None else 0
                                except Exception:
                                    pass
                                note["hdus"].append(item)
                    except Exception as e:
                        note["fits_error"]=type(e).__name__+": "+str(e)[:240]
                else:
                    note["note"]="No deep parser for this extension; inventory only."
            except Exception as e:
                note["error"]=type(e).__name__+": "+str(e)[:240]
            schema_notes.append(note)
    return inv, schema_notes, ext_counts

def main():
    lines=[]
    parse_candidates={}
    lines.append("JAA_REPRO_REBUILD STAGE 02A - LOCAL SCHEMA DISCOVERY")
    lines.append("Generated UTC: "+datetime.now(timezone.utc).isoformat())
    lines.append("Purpose: inspect the successfully downloaded Stage 01 files BEFORE writing scientific parsers.")
    lines.append("This stage does not fit, filter, or modify scientific data.")
    lines.append("")

    # Core text tables
    core=[
        RAW/"baumgardt_structural_combined.txt",
        RAW/"baumgardt_orbits_combined.txt",
    ]
    for p in core:
        lines.append("="*72)
        lines.append(f"CORE TABLE: {p.name}")
        if not p.exists():
            lines.append("STATUS: MISSING - Stage 02B must use HTML fallback.")
            html = RAW/("structural_html.html" if "structural" in p.name else "orbits_html.html")
            if html.exists():
                try:
                    tabs=pd.read_html(html)
                    lines.append(f"HTML fallback present: {html.name}; tables={len(tabs)}")
                    for i,t in enumerate(tabs[:5]):
                        lines.append(f"  table[{i}]: rows={len(t)}, cols={len(t.columns)}")
                        lines.append("  columns="+repr([str(c) for c in t.columns[:20]]))
                except Exception as e:
                    lines.append("HTML fallback parse error: "+repr(e))
            continue
        s=summarize_text_table(p)
        lines.append(f"STATUS: PRESENT; bytes={s['bytes']}; sha256={s['sha256']}")
        lines.append(f"Numeric-line modal token width: {s['numeric_mode_token_width']}")
        lines.append("First non-blank lines:")
        for x in s["sample_lines"]:
            lines.append("  "+x[:300])
        cands=try_pandas_candidates(p)
        parse_candidates[p.name]=cands
        lines.append("Pandas parse candidates:")
        for c in cands:
            if "error" in c:
                lines.append(f"  {c['method']}: ERROR {c['error']}")
            else:
                lines.append(f"  {c['method']}: rows={c['rows']}, cols={c['cols']}, columns={c['columns']}")
        lines.append("")

    # RV inventory
    rvdir=RAW/"rv_by_cluster"
    rvfiles=sorted(rvdir.glob("*.txt")) if rvdir.exists() else []
    lines.append("="*72)
    lines.append("INDIVIDUAL RV LAYER")
    lines.append(f"RV files present: {len(rvfiles)}")
    rvrows=[rv_file_profile(p) for p in rvfiles]
    pd.DataFrame(rvrows).to_csv(RV_INV,index=False)
    widths=Counter(str(r["mode_numeric_token_width"]) for r in rvrows if str(r["mode_numeric_token_width"]))
    lines.append("Modal numeric token-width distribution:")
    for k,v in widths.most_common(15):
        lines.append(f"  width={k}: files={v}")
    if rvfiles:
        idxs=sorted(set([0,1,2,len(rvfiles)//4,len(rvfiles)//2,3*len(rvfiles)//4,len(rvfiles)-3,len(rvfiles)-2,len(rvfiles)-1]))
        lines.append("Representative RV file headers:")
        for i in idxs:
            r=rvrows[i]
            lines.append(f"  [{Path(r['file']).name}] bytes={r['bytes']} width={r['mode_numeric_token_width']}")
            lines.append("    L1: "+r["first_nonblank"])
            lines.append("    L2: "+r["second_nonblank"])
    lines.append(f"Full RV schema inventory: {RV_INV.relative_to(ROOT)}")
    lines.append("")

    # Gaia zip
    gz=RAW/"vasiliev_baumgardt_2021_clusters.zip"
    lines.append("="*72)
    lines.append("GAIA EDR3 VALIDATION ARCHIVE")
    if not gz.exists():
        lines.append("STATUS: MISSING")
        gaia_notes=[]
    else:
        try:
            inv,gaia_notes,ext_counts=inspect_gaia_zip(gz)
            pd.DataFrame(inv).to_csv(GAIA_INV,index=False)
            lines.append(f"STATUS: PRESENT; bytes={gz.stat().st_size}; sha256={sha256_file(gz)}")
            lines.append(f"ZIP members: {len(inv)}")
            lines.append("Extension counts: "+", ".join(f"{k}={v}" for k,v in ext_counts.most_common()))
            lines.append("Representative members:")
            for n in gaia_notes:
                lines.append("  "+json.dumps(n, ensure_ascii=False)[:1800])
            lines.append(f"Full ZIP inventory: {GAIA_INV.relative_to(ROOT)}")
        except Exception as e:
            lines.append("ZIP INSPECTION ERROR: "+type(e).__name__+": "+str(e))
            gaia_notes=[]
    lines.append("")

    # Source manifest status
    man=OUT/"provenance_manifest.csv"
    lines.append("="*72)
    lines.append("PROVENANCE MANIFEST")
    if man.exists():
        m=pd.read_csv(man)
        lines.append(f"Manifest rows: {len(m)}")
        if "status" in m:
            counts=m["status"].astype(str).value_counts().to_dict()
            lines.append("Status counts: "+repr(counts))
            failed=m[m["status"].astype(str).str.startswith("failed", na=False)]
            lines.append(f"Failed/fallback rows: {len(failed)}")
            for _,r in failed.head(30).iterrows():
                lines.append(f"  {r.get('name','')} | {r.get('status','')} | {r.get('note','')}")
    else:
        lines.append("Manifest missing.")
    lines.append("")

    parse_candidates["gaia_representatives"]=gaia_notes
    CAND.write_text(json.dumps(parse_candidates,indent=2,ensure_ascii=False),encoding="utf-8")
    REPORT.write_text("\n".join(lines)+"\n",encoding="utf-8")

    print("JAA_REPRO_REBUILD STAGE 02A SUMMARY")
    print(f"Core structural file: {'YES' if core[0].exists() else 'NO'}")
    print(f"Core orbit file:      {'YES' if core[1].exists() else 'NO'}")
    print(f"RV files present:     {len(rvfiles)}")
    print(f"Gaia EDR3 ZIP:        {'YES' if gz.exists() else 'NO'}")
    if gz.exists():
        try:
            with zipfile.ZipFile(gz) as z:
                print(f"Gaia ZIP members:     {len([n for n in z.namelist() if not n.endswith('/')])}")
        except Exception:
            print("Gaia ZIP members:     ERROR")
    print("")
    print("REPORT WRITTEN:")
    print("  outputs\\stage02a_schema_report.txt")
    print("  outputs\\stage02a_rv_schema_inventory.csv")
    print("  outputs\\stage02a_gaia_zip_inventory.csv")
    print("  outputs\\stage02a_parse_candidates.json")
    print("")
    print("NEXT: send stage02a_schema_report.txt (or paste its contents).")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
